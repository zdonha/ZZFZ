#!/bin/bash
# Common Altibase iLoader for CCS_SUBS_TBL(0) and WOW_SUBS_TBL(1).
# ./load_subs.sh 0 FIRST_MDN LAST_MDN [TYPE] [--replace-range]
# ./load_subs.sh 1 FIRST_MDN LAST_MDN [--replace-range]
set -euo pipefail

usage()
{
    echo "USAGE: $0 SUC FIRST_MDN LAST_MDN [TYPE] [--replace-range]" >&2
    echo "  SUC  : 0=CCS, 1=WOW" >&2
    echo "  TYPE : 0=SMS, 3=FREE, 4=AL2A, 5=MEDIA (CCS only; default 0)" >&2
    echo "  EX   : $0 0 01010000000 01010000999 0" >&2
    echo "  EX   : $0 1 01010000000 01010000999 --replace-range" >&2
    exit 1
}

[[ $# -ge 3 ]] || usage
SUC=$1
FIRST_MDN=$2
LAST_MDN=$3
shift 3

[[ "$SUC" == 0 || "$SUC" == 1 ]] || usage
[[ "$FIRST_MDN" =~ ^0[0-9]{10}$ && "$LAST_MDN" =~ ^0[0-9]{10}$ ]] || usage

TYPE=0
TYPE_SPECIFIED=0
REPLACE=0
for opt in "$@"; do
    case "$opt" in
        --replace-range)
            [[ $REPLACE -eq 0 ]] || usage
            REPLACE=1
            ;;
        0|3|4|5)
            [[ $SUC -eq 0 && $TYPE_SPECIFIED -eq 0 ]] || usage
            TYPE=$opt
            TYPE_SPECIFIED=1
            ;;
        *)
            usage
            ;;
    esac
done

START=$((10#$FIRST_MDN))
END=$((10#$LAST_MDN))
(( START <= END )) || { echo "ERROR: FIRST_MDN > LAST_MDN" >&2; exit 1; }
EXPECTED=$((END - START + 1))

if [[ $SUC -eq 0 ]]; then
    TABLE=CCS_SUBS_TBL
    BASE_NAME=ccs_subs
    COLS=11
else
    TABLE=WOW_SUBS_TBL
    BASE_NAME=wow_subs
    COLS=7
fi

command -v iloader >/dev/null || { echo "ERROR: iloader not found in PATH" >&2; exit 1; }
if (( REPLACE )); then
    command -v isql >/dev/null || { echo "ERROR: isql not found in PATH" >&2; exit 1; }
fi

# SUBS_DB_* preferred. CCS_DB_* supported for compatibility with existing ccs.sh.
DB_HOST=${SUBS_DB_HOST:-${CCS_DB_HOST:-127.0.0.1}}
DB_USER=${SUBS_DB_USER:-${CCS_DB_USER:-ccs}}
DB_PORT=${SUBS_DB_PORT:-${CCS_DB_PORT:-}}
DB_PASS=${SUBS_DB_PASS:-${CCS_DB_PASS:-}}
if [[ -z "$DB_PASS" ]]; then
    read -r -s -p "${DB_USER}@${DB_HOST} DB password: " DB_PASS
    echo
fi
[[ -n "$DB_PASS" ]] || { echo "ERROR: empty DB password" >&2; exit 1; }

BASE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
FMT="$BASE_DIR/${BASE_NAME}.fmt"
DAT="$BASE_DIR/${BASE_NAME}.dat"
LOG="$BASE_DIR/${BASE_NAME}.log"
BAD="$BASE_DIR/${BASE_NAME}.bad"
DEL_LOG="$BASE_DIR/${BASE_NAME}_delete.log"
TMP_DAT=$(mktemp "${DAT}.tmp.XXXXXX")
trap 'rm -f "$TMP_DAT"' EXIT

CONN=(-s "$DB_HOST" -u "$DB_USER" -p "$DB_PASS")
if [[ -n "$DB_PORT" ]]; then
    CONN+=(-port "$DB_PORT")
fi

printf '[INFO] Table: %s, MDN: %s ~ %s, count=%s\n' "$TABLE" "$FIRST_MDN" "$LAST_MDN" "$EXPECTED"
if [[ $SUC -eq 0 ]]; then
    echo "[INFO] TYPE=$TYPE"
fi

# Generate iLoader FORM file from actual DB schema once per table.
if [[ ! -s "$FMT" ]]; then
    echo "[INFO] Generating $FMT ..."
    iloader formout "${CONN[@]}" -T "$TABLE" -f "$FMT"
    [[ -s "$FMT" ]] || { echo "ERROR: FORM generation failed: $FMT" >&2; exit 1; }
fi

FORM_COLS=$(awk '
    /^[[:space:]]*\{[[:space:]]*$/ { in_table=1; next }
    in_table && /^[[:space:]]*\}[[:space:]]*$/ { in_table=0 }
    in_table && /;/ { cols++ }
    END { print cols+0 }
' "$FMT")
if (( FORM_COLS != COLS )); then
    echo "ERROR: FORM columns=$FORM_COLS (expected $COLS). Check $FMT" >&2
    exit 1
fi

# .dat contains CSV records, not INSERT statements.
echo "[INFO] Generating $DAT ..."
if [[ $SUC -eq 0 ]]; then
    bash "$BASE_DIR/make_subs.sh" 0 "$FIRST_MDN" "$LAST_MDN" "$TYPE" > "$TMP_DAT"
else
    bash "$BASE_DIR/make_subs.sh" 1 "$FIRST_MDN" "$LAST_MDN" > "$TMP_DAT"
fi
ACTUAL=$(wc -l < "$TMP_DAT")
if (( ACTUAL != EXPECTED )); then
    echo "ERROR: DAT rows $ACTUAL != expected $EXPECTED" >&2
    exit 1
fi
awk -F, -v expected="$COLS" 'NR <= 3 && NF != expected {exit 1} NR == 3 {exit}' "$TMP_DAT" || {
    echo "ERROR: DAT does not have $COLS columns" >&2
    exit 1
}
mv -f "$TMP_DAT" "$DAT"
echo "[INFO] DAT generated: $ACTUAL rows"

if (( REPLACE )); then
    echo "[WARN] DELETE from $TABLE where MDN is $FIRST_MDN ~ $LAST_MDN (inclusive)"
    echo "[WARN] DELETE is committed independently of subsequent iLoader insertion."
    read -r -p 'Type DELETE to continue: ' ANSWER
    [[ "$ANSWER" == DELETE ]] || { echo '[INFO] Cancelled'; exit 1; }

    if ! {
        printf 'AUTOCOMMIT OFF;\n'
        printf "DELETE FROM %s WHERE MDN BETWEEN '%s' AND '%s';\n" "$TABLE" "$FIRST_MDN" "$LAST_MDN"
        printf 'COMMIT;\n'
    } | isql "${CONN[@]}" > "$DEL_LOG" 2>&1; then
        echo "ERROR: isql execution failed. See $DEL_LOG" >&2
        exit 1
    fi
    if grep -Eqi 'ERR-[0-9]+|(^|[[:space:]])ERROR([[:space:]:]|$)' "$DEL_LOG"; then
        echo "ERROR: DELETE reported an error. See $DEL_LOG" >&2
        exit 1
    fi
    echo "[INFO] DELETE completed; inspect $DEL_LOG"
fi

rm -f "$BAD" "$LOG"
echo '[INFO] iLoader started: -mode APPEND -array 1000 -commit 10 -atomic'
if ! iloader in "${CONN[@]}" \
    -f "$FMT" -d "$DAT" -mode APPEND \
    -array 1000 -commit 10 -atomic \
    -log "$LOG" -bad "$BAD"; then
    echo "ERROR: iLoader failed. See $LOG and $BAD" >&2
    exit 1
fi
if [[ -s "$BAD" ]]; then
    echo "ERROR: failed records found in $BAD" >&2
    exit 1
fi
if [[ -f "$LOG" ]] && grep -Eq 'Error Row Count[[:space:]]*:[[:space:]]*[1-9]' "$LOG"; then
    echo "ERROR: iLoader error count > 0. See $LOG" >&2
    exit 1
fi

LOADED=''
if [[ -f "$LOG" ]]; then
    LOADED=$(awk -F: '/Load Row Count[[:space:]]*:/ {
        gsub(/[^0-9]/, "", $2)
        print $2
        exit
    }' "$LOG")
fi
if [[ -n "$LOADED" && "$LOADED" -ne "$EXPECTED" ]]; then
    echo "ERROR: reported load count $LOADED != expected $EXPECTED" >&2
    exit 1
fi

echo "[OK] $TABLE: iLoader finished. Expected $EXPECTED rows. Check $LOG"
