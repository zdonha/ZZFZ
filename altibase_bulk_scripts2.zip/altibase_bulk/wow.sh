#!/bin/bash
# WOW subscriber loader.
# Usage: ./wow.sh FIRST_MDN LAST_MDN [--replace-range]
set -euo pipefail
BASE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
exec bash "$BASE_DIR/load_subs.sh" 1 "$@"
