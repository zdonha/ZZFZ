#!/bin/bash
# CCS subscriber loader, kept compatible with the previous CLI.
# Usage: ./ccs.sh FIRST_MDN LAST_MDN [TYPE] [--replace-range]
set -euo pipefail
BASE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
exec bash "$BASE_DIR/load_subs.sh" 0 "$@"
