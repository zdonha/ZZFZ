# Altibase CCS / WOW Bulk 가입자 생성 (RHEL 8.10)

## 구성

- `make_subs.sh`: `CCS(0)` 또는 `WOW(1)` iLoader `.dat` 생성. DB 접속 없음
- `load_subs.sh`: 공통 로더. `FORM` 생성, `.dat` 생성, 선택적 범위 삭제, iLoader 입력
- `ccs.sh`: CCS 전용 실행 파일 (`load_subs.sh 0` 래퍼)
- `wow.sh`: WOW 전용 실행 파일 (`load_subs.sh 1` 래퍼)

| 구분 | 테이블 | 데이터 컬럼 수 | 출력 파일 |
|---|---|---:|---|
| CCS | `CCS_SUBS_TBL` | 11 | `ccs_subs.{fmt,dat,log,bad}` |
| WOW | `WOW_SUBS_TBL` | 7 | `wow_subs.{fmt,dat,log,bad}` |

## 준비

```bash
chmod +x make_subs.sh load_subs.sh ccs.sh wow.sh
export PATH="$ALTIBASE_HOME/bin:$PATH"
```

기본 접속 정보: `127.0.0.1`, 사용자 `ccs`; 실행 시 비밀번호를 입력합니다.
접속 정보를 바꾸려면 `SUBS_DB_HOST`, `SUBS_DB_USER`, `SUBS_DB_PORT`, `SUBS_DB_PASS` 환경변수를 지정합니다.
기존 `CCS_DB_*` 환경변수도 호환됩니다. 비밀번호 환경변수는 프로세스 환경 노출 가능성에 주의하세요.

## 1. 데이터 생성만 시험 (DB 변경 없음)

```bash
./make_subs.sh 0 01010000000 01010000009 0 > ccs_test.dat
./make_subs.sh 1 01010000000 01010000009 > wow_test.dat
head -3 ccs_test.dat
head -3 wow_test.dat
wc -l ccs_test.dat wow_test.dat
```

CCS: `"01010000000","450001010000000",0,0,0,0,"",0,0,0,0`

WOW: `"01010000000","450001010000000",0,0,0,"",0`

첫 줄이 MDN, IMSI, 기타 값의 **컬럼 순서가 실제 테이블과 일치**하는지 검사하세요.

## 2. CCS 가입자 입력

```bash
./ccs.sh 01010000000 01010000999 0
```

`TYPE`: `0=SMS`, `3=FREE`, `4=AL2A`, `5=MEDIA` (기본값 `0`)

## 3. WOW 가입자 입력

```bash
./wow.sh 01010000000 01010000999
```

WOW에는 `TYPE` 인자가 없습니다.

## 4. 지정 범위의 기존 가입자를 삭제하고 재입력

```bash
./ccs.sh 01010000000 01010000999 0 --replace-range
./wow.sh 01010000000 01010000999 --replace-range
```

`DELETE`를 직접 입력해야 실행됩니다. 삭제는 별도 커밋되므로 **이후 입력이 실패해도 기존 가입자는 복구되지 않습니다.**
범위는 양 끝 포함(`BETWEEN`)입니다. 대량 DELETE는 로그·잠금 부하를 검토하세요.

## 5. 직접 공통 로더 실행

```bash
./load_subs.sh 0 01010000000 01010000999 0
./load_subs.sh 1 01010000000 01010000999
```

## iLoader / 사전 검증

- 처음 실행할 때 DB에서 각 테이블의 `FORM` 파일(`*.fmt`)을 생성합니다.
- 스크립트는 CCS 11개 컬럼, WOW 7개 컬럼인지 확인합니다.
- **실제 테이블 타입 및 필드 순서와 데이터 내용은 운영자가 확인**해야 합니다.
- `-mode APPEND -array 1000 -commit 10 -atomic`: 배열 1,000건, 10배열마다 커밋
- `*.log` / `*.bad`에서 결과 및 실패건 확인. `-mode REPLACE`는 테이블 전체를 삭제할 수 있어 사용하지 않습니다.
- 데이터 내의 `""` 값이 기존 SQL의 `''`와 동일하게 반영되는지 10건 시험을 권장합니다.
- MDN과 IMSI는 각각 11자리, 15자리로 앞자리 `0`을 보존합니다.
- 실제 DB에서 10건 → 1,000건 → 10만 건 순으로 검증 후 범위를 확장하세요.
- iLoader 비밀번호 인수는 프로세스 목록에서 확인될 수 있으므로 작업 권한에 주의하세요.

## DB 입력 후 건수 검증 예시

```sql
SELECT COUNT(*) FROM CCS_SUBS_TBL
WHERE MDN BETWEEN '01010000000' AND '01010000999';

SELECT COUNT(*) FROM WOW_SUBS_TBL
WHERE MDN BETWEEN '01010000000' AND '01010000999';
```
