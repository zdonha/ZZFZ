#!/bin/bash

set -e
shopt -s nullglob
cd -- "$(dirname -- "$0")"

files=(./libsrc/*/*.[chp] ./libsrc/*/*.sc ./include/*.h ./include/*/*.h)
if ((${#files[@]})); then
    ctags --langmap=c:+.sc.p "${files[@]}"
fi

for dir in ./src/*/; do
    (
        cd -- "$dir"
        files=(*.[chp])
        if ((${#files[@]})); then
            ctags --langmap=c:+.p "${files[@]}"
        fi
    )
done
