#define _GNU_SOURCE
#include "kmslib.h"

#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/mman.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <unistd.h>

/* Default for callers that do not supply the package key at startup. */
#ifndef KMSLIB_SHM_KEY
#define KMSLIB_SHM_KEY 0x1111
#endif

static key_t kms_shm_key = KMSLIB_SHM_KEY;

int kmslib_set_shm_key(long key)
{
    key_t ipc_key = (key_t)key;

    if (ipc_key == IPC_PRIVATE || (long)ipc_key != key) {
        fprintf(stderr, "  [%s] invalid SHM key: %ld\n", __func__, key);
        return 0;
    }

    kms_shm_key = ipc_key;
    return 1;
}

typedef struct {
    char section[KMSLIB_SECTION_SIZE];
    char policy[KMSLIB_POLICY_SIZE];
    char user[KMSLIB_USER_SIZE];
    char new_pwd_enc[KMSLIB_ENC_SIZE];
    char old_pwd_enc[KMSLIB_ENC_SIZE];
} CONFIG_CREDENTIAL;

enum credential_config_action {
    CREDENTIAL_ADD,
    CREDENTIAL_CHANGE,
    CREDENTIAL_DELETE
};

static void wipe(void *data, size_t len)
{
    volatile unsigned char *p = data;

    while (len--) {
        *p++ = 0;
    }
}

void kmslib_clear_buffer(void *buffer, size_t size)
{
    if (buffer) {
        wipe(buffer, size);
    }
}

void kmslib_clear_credential(KMS_CREDENTIAL *cred)
{
    if (cred) {
        wipe(cred, sizeof(*cred));
    }
}

static int copy_string(char *dest, size_t dest_size, const char *src)
{
    size_t len;

    if (!dest || !src || dest_size == 0) {
        return 0;
    }

    len = strlen(src);
    if (len >= dest_size) {
        return 0;
    }

    memcpy(dest, src, len + 1);
    return 1;
}

static char *trim(char *s)
{
    char *end;

    while (*s && isspace((unsigned char)*s)) {
        ++s;
    }

    end = s + strlen(s);
    while (end > s && isspace((unsigned char)end[-1])) {
        *--end = '\0';
    }

    return s;
}

static int parse_credential_file(const char *filename, CONFIG_CREDENTIAL *cfg, int *count)
{
    FILE *fp;
    char line[2048];
    char *key;
    char *val;
    char *eq;
    int n = 0;
    int index = -1;
    int line_no = 0;
    int i;

    if (!filename || !*filename || !cfg || !count) {
        fprintf(stderr, "  [%s] invalid credential file arguments\n", __func__);
        return 0;
    }

    fp = fopen(filename, "r");
    if (!fp) {
        int saved_errno = errno;

        fprintf(stderr, "  [%s] cannot open credential file '%s': %s\n", __func__, filename, strerror(saved_errno));
        return 0;
    }

    while (fgets(line, sizeof(line), fp)) {
        line_no++;
        if (!strchr(line, '\n') && !feof(fp)) {
            goto invalid_line;
        }

        key = trim(line);
        if (!*key || *key == '#' || *key == ';') {
            continue;
        }

        if (*key == '[') {
            char *end = strchr(key, ']');
            int j;

            if (!end || *trim(end + 1)) {
                goto invalid_line;
            }

            *end = '\0';
            if (!key[1] || n >= MAX_CREDENTIAL) {
                goto invalid_line;
            }

            for (j = 0; j < n; j++) {
                if (!strcmp(cfg[j].section, key + 1)) {
                    goto invalid_line;
                }
            }

            index = n++;
            if (!copy_string(cfg[index].section, sizeof(cfg[index].section), key + 1)) {
                goto invalid_line;
            }
            continue;
        }

        eq = strchr(key, '=');
        if (index < 0 || !eq) {
            goto invalid_line;
        }

        *eq = '\0';
        val = trim(eq + 1);
        key = trim(key);

        if (!strcmp(key, "USER")) {
            if (!copy_string(cfg[index].user, sizeof(cfg[index].user), val)) {
                goto invalid_line;
            }
        } else if (!strcmp(key, "POLICY")) {
            if (!copy_string(cfg[index].policy, sizeof(cfg[index].policy), val)) {
                goto invalid_line;
            }
        } else if (!strcmp(key, "PWD_ENC_NEW")) {
            if (!copy_string(cfg[index].new_pwd_enc, sizeof(cfg[index].new_pwd_enc), val)) {
                goto invalid_line;
            }
        } else if (!strcmp(key, "PWD_ENC_OLD")) {
            if (!copy_string(cfg[index].old_pwd_enc, sizeof(cfg[index].old_pwd_enc), val)) {
                goto invalid_line;
            }
        } else {
            goto invalid_line;
        }
    }

    if (ferror(fp)) {
        fprintf(stderr, "  [%s] failed to read credential file '%s' after line %d\n", __func__, filename, line_no);
        fclose(fp);
        return 0;
    }

    for (i = 0; i < n; ++i) {
        if (!cfg[i].user[0] || !cfg[i].policy[0] || (!cfg[i].new_pwd_enc[0] && !cfg[i].old_pwd_enc[0])) {
            fprintf(stderr, "  [%s] missing credential fields in section [%s] of '%s'\n",
                    __func__, cfg[i].section, filename);
            fclose(fp);
            return 0;
        }
    }

    *count = n;
    fclose(fp);
    return 1;

invalid_line:
    fprintf(stderr, "  [%s] invalid credential config at '%s':%d\n", __func__, filename, line_no);
    fclose(fp);
    return 0;
}

static int shm_is_ready(const SHM_KMS_CREDENTIAL *shm)
{
    /* A positive update_time indicates that the cache has been initialized. */
    return shm->update_time > 0 && shm->credential_count >= 0 && shm->credential_count <= MAX_CREDENTIAL;
}

static KMS_CREDENTIAL *find_credential(SHM_KMS_CREDENTIAL *shm, const char *section)
{
    int i;

    for (i = 0; i < shm->credential_count; i++) {
        if (strcmp(shm->credential[i].section, section) == 0) {
            return &shm->credential[i];
        }
    }

    return NULL;
}

static int lock_shm(void)
{
    int semid;
    int result;
    /* Linux initializes a new semaphore to zero (unlocked). */
    struct sembuf ops[] = {
        {0, 0, 0},
        {0, 1, SEM_UNDO}
    };

    semid = semget(kms_shm_key, 1, IPC_CREAT | 0600);
    if (semid < 0) {
        fprintf(stderr, "  [%s] semget failed: %s\n", __func__, strerror(errno));
        return -1;
    }

    /* Wait for zero and acquire the lock atomically. */
    do {
        result = semop(semid, ops, sizeof(ops) / sizeof(ops[0]));
    } while (result < 0 && errno == EINTR);

    if (result < 0) {
        fprintf(stderr, "  [%s] semop lock failed: %s\n", __func__, strerror(errno));
        return -1;
    }

    return semid;
}

static int unlock_shm(int semid)
{
    struct sembuf op = {0, -1, SEM_UNDO | IPC_NOWAIT};

    if (semop(semid, &op, 1) < 0) {
        fprintf(stderr, "  [%s] semop unlock failed: %s\n", __func__, strerror(errno));
        return 0;
    }

    return 1;
}

static int attach_locked(int *lock_id, SHM_KMS_CREDENTIAL **shm)
{
    int semid;
    int shmid;
    void *address;

    semid = lock_shm();
    if (semid < 0) {
        return 0;
    }

    shmid = shmget(kms_shm_key, sizeof(SHM_KMS_CREDENTIAL), IPC_CREAT | 0600);
    if (shmid < 0) {
        /* Old incompatible size: requires manual IPC cleanup. */
        fprintf(stderr, "  [%s] shmget failed: %s\n", __func__, strerror(errno));
        goto fail;
    }

    address = shmat(shmid, NULL, 0);
    if (address == (void *)-1) {
        fprintf(stderr, "  [%s] shmat failed: %s\n", __func__, strerror(errno));
        goto fail;
    }

    if (madvise(address, sizeof(SHM_KMS_CREDENTIAL), MADV_DONTDUMP) != 0) {
        fprintf(stderr, "  [%s] madvise(MADV_DONTDUMP) failed: %s\n", __func__, strerror(errno));
        shmdt(address);
        goto fail;
    }

    *lock_id = semid;
    *shm = address;
    return 1;

fail:
    unlock_shm(semid);
    return 0;
}

static int detach_locked(int semid, SHM_KMS_CREDENTIAL *shm)
{
    shmdt(shm);
    return unlock_shm(semid);
}

static void free_credential_cache(SHM_KMS_CREDENTIAL *candidate)
{
    if (candidate) {
        wipe(candidate, sizeof(*candidate));
        free(candidate);
    }
}

static SHM_KMS_CREDENTIAL *prepare_credential_cache(const char *filename, int reload)
{
    CONFIG_CREDENTIAL cfg[MAX_CREDENTIAL];
    SHM_KMS_CREDENTIAL *candidate = NULL;
    time_t now;
    int count = 0;
    int i;
    int kms_active = 0;
    int ok = 0;

    memset(cfg, 0, sizeof(cfg));
    candidate = calloc(1, sizeof(*candidate));
    if (!candidate) {
        fprintf(stderr, "  [%s] cannot allocate credential data: %s\n", __func__, strerror(errno));
        goto done;
    }

    if (!parse_credential_file(filename, cfg, &count)) {
        goto done;
    }

    if (reload || count > 0) {
        if (!(reload ? reload_kms_properties() : kmslib_init())) {
            fprintf(stderr, "  [%s] KMS initialization failed\n", __func__);
            goto done;
        }
        kms_active = 1;
    }

    for (i = 0; i < count; i++) {
        KMS_CREDENTIAL *dst = &candidate->credential[i];

        if (!copy_string(dst->section, sizeof(dst->section), cfg[i].section) ||
            !copy_string(dst->user, sizeof(dst->user), cfg[i].user) ||
            !copy_string(dst->policy, sizeof(dst->policy), cfg[i].policy) ||
            !copy_string(dst->new_pwd_enc, sizeof(dst->new_pwd_enc), cfg[i].new_pwd_enc) ||
            !copy_string(dst->old_pwd_enc, sizeof(dst->old_pwd_enc), cfg[i].old_pwd_enc)) {
            fprintf(stderr, "  [%s] credential copy failed for section [%s]\n", __func__, cfg[i].section);
            goto done;
        }

        /* NEW is primary, OLD is the fallback. */
        if (dst->new_pwd_enc[0]) {
            if (!kmslib_decrypt(dst->policy, dst->new_pwd_enc, dst->new_pwd, sizeof(dst->new_pwd))) {
                fprintf(stderr, "  [%s] KMS decrypt failed for section [%s], field PWD_ENC_NEW\n",
                        __func__, dst->section);
                goto done;
            }
            dst->has_new = 1;
        }

        if (dst->old_pwd_enc[0]) {
            if (!kmslib_decrypt(dst->policy, dst->old_pwd_enc, dst->old_pwd, sizeof(dst->old_pwd))) {
                fprintf(stderr, "  [%s] KMS decrypt failed for section [%s], field PWD_ENC_OLD\n",
                        __func__, dst->section);
                goto done;
            }
            dst->has_old = 1;
        }
    }

    now = time(NULL);
    if (now == (time_t)-1) {
        fprintf(stderr, "  [%s] time failed: %s\n", __func__, strerror(errno));
        goto done;
    }

    candidate->credential_count = count;
    candidate->kms_link_time = count > 0 ? now : 0;
    candidate->update_time = now;
    candidate->expire_time = 0;  /* Reserved; no automatic invalidation. */
    ok = 1;

done:
    if (kms_active) {
        kmslib_cleanup();
    }
    wipe(cfg, sizeof(cfg));
    if (!ok) {
        free_credential_cache(candidate);
        return NULL;
    }
    return candidate;
}

static void publish_credential_cache(SHM_KMS_CREDENTIAL *shm, SHM_KMS_CREDENTIAL *candidate)
{
    time_t now = candidate->update_time;

    candidate->update_time = 0;
    __atomic_store_n(&shm->update_time, 0, __ATOMIC_SEQ_CST);
    memcpy(shm, candidate, sizeof(*candidate));
    __atomic_store_n(&shm->update_time, now, __ATOMIC_RELEASE);
}

int kmslib_get_shm_status(KMS_SHM_STATUS *status)
{
    struct shmid_ds info;
    const SHM_KMS_CREDENTIAL *shm;
    int semid;
    int shmid;
    int ok;
    int i;

    if (!status) {
        return 0;
    }
    memset(status, 0, sizeof(*status));
    status->key = (long)kms_shm_key;
    status->shmid = -1;
    shmid = shmget(kms_shm_key, 1, 0600);
    if (shmid < 0) {
        return errno == ENOENT;
    }
    semid = lock_shm();
    if (semid < 0) {
        return 0;
    }
    ok = 0;
    shmid = shmget(kms_shm_key, 1, 0600);
    if (shmid < 0) {
        ok = errno == ENOENT;
        goto done;
    }
    if (shmctl(shmid, IPC_STAT, &info) != 0) {
        goto done;
    }
    status->exists = 1;
    status->shmid = shmid;
    status->size = info.shm_segsz;
    status->attachments = (unsigned long)info.shm_nattch;
    if (info.shm_segsz != sizeof(*shm)) {
        ok = 1;
        goto done;
    }
    shm = shmat(shmid, NULL, SHM_RDONLY);
    if (shm == (void *)-1) {
        goto done;
    }
    status->ready = shm_is_ready(shm);
    if (status->ready) {
        status->credential_count = shm->credential_count;
        status->update_time = shm->update_time;
        status->kms_link_time = shm->kms_link_time;
        status->expire_time = shm->expire_time;
        memcpy(status->reserved, shm->reserved, sizeof(status->reserved));
        for (i = 0; i < shm->credential_count; i++) {
            memcpy(status->credential[i].section, shm->credential[i].section, KMSLIB_SECTION_SIZE);
            memcpy(status->credential[i].policy, shm->credential[i].policy, KMSLIB_POLICY_SIZE);
            memcpy(status->credential[i].user, shm->credential[i].user, KMSLIB_USER_SIZE);
            status->credential[i].section[KMSLIB_SECTION_SIZE - 1] = '\0';
            status->credential[i].policy[KMSLIB_POLICY_SIZE - 1] = '\0';
            status->credential[i].user[KMSLIB_USER_SIZE - 1] = '\0';
            status->credential[i].has_new = shm->credential[i].has_new;
            status->credential[i].has_old = shm->credential[i].has_old;
        }
    }
    ok = shmdt(shm) == 0;
done:
    return unlock_shm(semid) && ok;
}

int kmslib_restore_local_cache(void)
{
    KmsCredential cred[KMS_CACHE_MAX] = {0};
    SHM_KMS_CREDENTIAL *candidate;
    SHM_KMS_CREDENTIAL *shm;
    struct shmid_ds info;
    size_t count;
    size_t i;
    int semid;
    int shmid;
    int ok;

    candidate = calloc(1, sizeof(*candidate));
    if (!candidate) {
        return 0;
    }
    semid = -1;
    shmid = -1;
    shm = (void *)-1;
    ok = 0;
    /* Validate first; no credential configuration parsing or KMS calls. */
    if (!kms_cache_read(KMS_CACHE_KEY_PATH, KMS_CACHE_FILE_PATH,
                        cred, KMS_CACHE_MAX, &count) || count > MAX_CREDENTIAL) {
        fprintf(stderr, "  [%s] cache validation failed\n", __func__);
        goto done;
    }
    for (i = 0; i < count; i++) {
        if (!copy_string(candidate->credential[i].section, KMSLIB_SECTION_SIZE, cred[i].section) ||
            !copy_string(candidate->credential[i].user, KMSLIB_USER_SIZE, cred[i].id) ||
            !copy_string(candidate->credential[i].new_pwd, KMSLIB_PWD_SIZE, cred[i].pwd)) {
            fprintf(stderr, "  [%s] cache field exceeds SHM capacity\n", __func__);
            goto done;
        }
        candidate->credential[i].has_new = 1;
    }
    candidate->credential_count = (int)count;
    candidate->update_time = time(NULL);
    if (candidate->update_time <= 0) {
        goto done;
    }
    semid = lock_shm();
    if (semid < 0) {
        goto done;
    }
    shmid = shmget(kms_shm_key, 1, 0600);
    if (shmid >= 0) {
        if (shmctl(shmid, IPC_STAT, &info) != 0) {
            goto done;
        }
        if (info.shm_nattch != 0) {
            fprintf(stderr, "  [%s] SHM is in use; stop all blocks first\n", __func__);
            goto done;
        }
        if (shmctl(shmid, IPC_RMID, NULL) != 0) {
            goto done;
        }
    } else if (errno != ENOENT) {
        goto done;
    }
    shmid = shmget(kms_shm_key, sizeof(*shm), IPC_CREAT | IPC_EXCL | 0600);
    if (shmid < 0) {
        goto done;
    }
    shm = shmat(shmid, NULL, 0);
    if (shm == (void *)-1 || madvise(shm, sizeof(*shm), MADV_DONTDUMP) != 0) {
        if (shm != (void *)-1) {
            shmdt(shm);
            shm = (void *)-1;
        }
        shmctl(shmid, IPC_RMID, NULL);
        goto done;
    }
    publish_credential_cache(shm, candidate);
    ok = 1;
done:
    if (shm != (void *)-1) {
        ok = (shmdt(shm) == 0) && ok;
    }
    if (semid >= 0) {
        ok = unlock_shm(semid) && ok;
    }
    kms_cache_clear(cred, KMS_CACHE_MAX);
    free_credential_cache(candidate);
    return ok;
}

static int populate(const char *filename, SHM_KMS_CREDENTIAL *shm)
{
    SHM_KMS_CREDENTIAL *candidate = prepare_credential_cache(filename, 0);

    if (!candidate) {
        return 0;
    }

    publish_credential_cache(shm, candidate);
    free_credential_cache(candidate);
    return 1;
}

static int stat_reload_file(const char *filename, struct stat *info)
{
    if (stat(filename, info) < 0) {
        fprintf(stderr, "  [%s] cannot stat '%s': %s\n", __func__, filename, strerror(errno));
        return 0;
    }
    return 1;
}

static int reload_file_unchanged(const char *filename, const struct stat *original)
{
    struct stat current;

    if (!stat_reload_file(filename, &current)) {
        return 0;
    }

    if (current.st_dev == original->st_dev && current.st_ino == original->st_ino &&
        current.st_size == original->st_size &&
        current.st_mtim.tv_sec == original->st_mtim.tv_sec && current.st_mtim.tv_nsec == original->st_mtim.tv_nsec &&
        current.st_ctim.tv_sec == original->st_ctim.tv_sec && current.st_ctim.tv_nsec == original->st_ctim.tv_nsec) {
        return 1;
    }

    fprintf(stderr, "  [%s] '%s' changed during reload; retry the command\n", __func__, filename);
    return 0;
}

int kmslib_reload_credentials(void)
{
    const char *filename = kmslib_get_credential_file();
    SHM_KMS_CREDENTIAL *candidate;
    SHM_KMS_CREDENTIAL *shm;
    struct stat credentials;
    struct stat properties;
    int semid;
    int ok = 0;

    if (!filename || !*filename) {
        fprintf(stderr, "  [%s] invalid credential file path\n", __func__);
        return 0;
    }

    if (!stat_reload_file(filename, &credentials) || !stat_reload_file(KMSLIB_PROPERTIES_FILE, &properties)) {
        return 0;
    }

    candidate = prepare_credential_cache(filename, 1);
    if (!candidate) {
        return 0;
    }

    if (attach_locked(&semid, &shm)) {
        if (reload_file_unchanged(filename, &credentials) && reload_file_unchanged(KMSLIB_PROPERTIES_FILE, &properties)) {
            publish_credential_cache(shm, candidate);
            ok = 1;
        }
        ok = detach_locked(semid, shm) && ok;
    }

    free_credential_cache(candidate);
    return ok;
}

int kmslib_load_credential(SHM_KMS_CREDENTIAL **shm)
{
    const char *filename = kmslib_get_credential_file();
    int semid;
    SHM_KMS_CREDENTIAL *attached;

    if (!shm) {
        fprintf(stderr, "  [%s] line=%d: output SHM pointer is NULL\n", __func__, __LINE__);
        return 0;
    }

    if (*shm) {
        return 1;
    }

    if (!attach_locked(&semid, &attached)) {
        fprintf(stderr, "  [%s] line=%d: attach_locked() failed\n", __func__, __LINE__);
        return 0;
    }

    if (!shm_is_ready(attached) && !populate(filename, attached)) {
        detach_locked(semid, attached);
        fprintf(stderr, "  [%s] line=%d: SHM was not ready and populate() failed\n", __func__, __LINE__);
        return 0;
    }

    if (!unlock_shm(semid)) {
        shmdt(attached);
        fprintf(stderr, "  [%s] line=%d: unlock_shm() failed\n", __func__, __LINE__);
        return 0;
    }

    *shm = attached;
    return 1;
}

int kmslib_detach_credential(SHM_KMS_CREDENTIAL **shm)
{
    if (!shm || !*shm) {
        return 1;
    }

    if (shmdt(*shm) != 0) {
        fprintf(stderr, "  [%s] shmdt failed: %s\n", __func__, strerror(errno));
        return 0;
    }

    *shm = NULL;
    return 1;
}

int kmslib_get_shm_snapshot(const SHM_KMS_CREDENTIAL *shm, SHM_KMS_CREDENTIAL *snapshot)
{
    int semid;
    int ok = 0;

    if (!shm || !snapshot || shm == snapshot) {
        return 0;
    }

    semid = lock_shm();
    if (semid < 0) {
        return 0;
    }

    if (shm_is_ready(shm)) {
        memcpy(snapshot, shm, sizeof(*snapshot));
        ok = 1;
    }

    if (!unlock_shm(semid)) {
        wipe(snapshot, sizeof(*snapshot));
        return 0;
    }

    return ok;
}

static int check_config_target(const char *filename, const char *section, int replace)
{
    CONFIG_CREDENTIAL cfg[MAX_CREDENTIAL] = {0};
    int count;
    int i;

    if (!parse_credential_file(filename, cfg, &count)) {
        return 0;
    }

    if (!replace && count >= MAX_CREDENTIAL) {
        fprintf(stderr, "  [%s] credential file is full\n", __func__);
        return 0;
    }

    for (i = 0; i < count; i++) {
        if (strcmp(cfg[i].section, section) == 0) {
            if (replace) {
                return 1;
            }
            fprintf(stderr, "  [%s] section [%s] already exists in the credential file\n", __func__, section);
            return 0;
        }
    }

    if (replace) {
        fprintf(stderr, "  [%s] section [%s] is missing from the credential file\n", __func__, section);
        return 0;
    }

    return 1;
}

static int write_credential_fields(FILE *dst, const KMS_CREDENTIAL *cred)
{
    return fprintf(dst, "USER=%s\nPOLICY=%s\nPWD_ENC_NEW=%s\nPWD_ENC_OLD=%s\n",
                   cred->user, cred->policy, cred->new_pwd_enc, cred->old_pwd_enc) >= 0;
}

static int write_credential_config(FILE *src, FILE *dst, const KMS_CREDENTIAL *cred,
                                   enum credential_config_action action)
{
    char line[2048];
    const char *text;
    size_t section_len = strlen(cred->section);
    int in_target = 0;
    int found = 0;

    while (fgets(line, sizeof(line), src)) {
        if (action != CREDENTIAL_ADD) {
            text = line + strspn(line, " \t\r\n\v\f");
            if (*text == '[') {
                in_target = strncmp(text + 1, cred->section, section_len) == 0 && text[section_len + 1] == ']';
                if (in_target) {
                    if (action == CREDENTIAL_CHANGE &&
                        (fprintf(dst, "[%s]\n", cred->section) < 0 || !write_credential_fields(dst, cred))) {
                        return 0;
                    }
                    found = 1;
                    continue;
                }
            } else if (in_target && *text && *text != '#' && *text != ';') {
                continue;
            }
        }

        if (fprintf(dst, "%s", line) < 0) {
            return 0;
        }
    }

    if (ferror(src)) {
        return 0;
    }

    if (action != CREDENTIAL_ADD) {
        if (!found) {
            errno = ENOENT;
        }
        return found;
    }

    return fprintf(dst, "\n[%s]\n", cred->section) >= 0 && write_credential_fields(dst, cred);
}

static int backup_credential_file(FILE *src, const char *filename)
{
    FILE *backup = NULL;
    struct stat info;
    char temp_path[PATH_MAX];
    char previous[PATH_MAX];
    char next[PATH_MAX];
    char buf[4096];
    const char suffix[] = ".conf";
    const char *slash = strrchr(filename, '/');
    size_t dir_len = slash ? (size_t)(slash + 1 - filename) : 0;
    size_t stem_len = strlen(filename);
    int hidden_stem_len;
    size_t n;
    int path_len;
    int fd;
    int slot;
    int saved_errno;

    if (stem_len >= sizeof(suffix) - 1 && strcmp(filename + stem_len - (sizeof(suffix) - 1), suffix) == 0) {
        stem_len -= sizeof(suffix) - 1;
    }
    if (stem_len >= sizeof(temp_path) - sizeof(".bak.XXXXXX")) {
        fprintf(stderr, "  [%s] credential backup path is too long\n", __func__);
        return 0;
    }

    hidden_stem_len = (int)stem_len + 1;
    path_len = snprintf(temp_path, sizeof(temp_path), "%.*s.%.*s.bak.XXXXXX",
                        (int)dir_len, filename, (int)(stem_len - dir_len), filename + dir_len);
    if (path_len < 0 || (size_t)path_len >= sizeof(temp_path)) {
        fprintf(stderr, "  [%s] credential backup path is too long\n", __func__);
        return 0;
    }

    if (fseek(src, 0, SEEK_SET) != 0) {
        fprintf(stderr, "  [%s] cannot reread '%s': %s\n", __func__, filename, strerror(errno));
        return 0;
    }

    fd = mkstemp(temp_path);
    if (fd < 0) {
        fprintf(stderr, "  [%s] cannot create temporary backup: %s\n", __func__, strerror(errno));
        return 0;
    }

    if (fchmod(fd, S_IRUSR | S_IWUSR) != 0 || !(backup = fdopen(fd, "wb"))) {
        goto fail;
    }
    fd = -1;

    while ((n = fread(buf, 1, sizeof(buf), src)) > 0) {
        if (fwrite(buf, 1, n, backup) != n) {
            goto fail;
        }
    }
    if (ferror(src) || fflush(backup) != 0 || fsync(fileno(backup)) != 0) {
        goto fail;
    }

    if (fclose(backup) != 0) {
        backup = NULL;
        goto fail;
    }
    backup = NULL;

    for (slot = 9; slot > 1; slot--) {
        snprintf(previous, sizeof(previous), "%.*s.bak%d", hidden_stem_len, temp_path, slot - 1);
        snprintf(next, sizeof(next), "%.*s.bak%d", hidden_stem_len, temp_path, slot);

        if (lstat(previous, &info) != 0) {
            if (errno == ENOENT) {
                continue;
            }
            goto fail;
        }
        if (!S_ISREG(info.st_mode)) {
            errno = EINVAL;
            goto fail;
        }
        if (rename(previous, next) != 0) {
            goto fail;
        }
    }

    snprintf(next, sizeof(next), "%.*s.bak1", hidden_stem_len, temp_path);
    if (rename(temp_path, next) != 0) {
        goto fail;
    }
    return 1;

fail:
    saved_errno = errno;
    if (backup) {
        fclose(backup);
    }
    if (fd >= 0) {
        close(fd);
    }
    unlink(temp_path);
    fprintf(stderr, "  [%s] cannot back up '%s': %s\n", __func__, filename, strerror(saved_errno));
    return 0;
}

static int save_credential(const char *filename, const KMS_CREDENTIAL *cred, enum credential_config_action action,
                           SHM_KMS_CREDENTIAL *shm)
{
    FILE *src;
    FILE *dst = NULL;
    char temp_path[PATH_MAX];
    time_t old_update_time;
    int path_len;
    int fd;
    int ok = 0;

    path_len = snprintf(temp_path, sizeof(temp_path), "%s.XXXXXX", filename);
    if (path_len < 0 || (size_t)path_len >= sizeof(temp_path)) {
        fprintf(stderr, "  [%s] credential file path is too long\n", __func__);
        return 0;
    }

    src = fopen(filename, "r");
    if (!src) {
        fprintf(stderr, "  [%s] cannot open '%s': %s\n", __func__, filename, strerror(errno));
        return 0;
    }

    fd = mkstemp(temp_path);
    if (fd < 0) {
        fprintf(stderr, "  [%s] cannot create temporary credential file: %s\n", __func__, strerror(errno));
        fclose(src);
        return 0;
    }

    dst = fdopen(fd, "w");
    if (!dst) {
        fprintf(stderr, "  [%s] fdopen() failed: %s\n", __func__, strerror(errno));
        close(fd);
        goto done;
    }

    if (!write_credential_config(src, dst, cred, action) || fflush(dst) != 0 || fsync(fd) != 0) {
        goto io_error;
    }

    if (fclose(dst) != 0) {
        dst = NULL;
        goto io_error;
    }
    dst = NULL;

    if (!backup_credential_file(src, filename)) {
        goto done;
    }

    /* If interrupted before SHM is updated, the next startup reloads the file. */
    old_update_time = shm->update_time;
    shm->update_time = 0;
    if (rename(temp_path, filename) != 0) {
        shm->update_time = old_update_time;
        goto io_error;
    }

    ok = 1;
    goto done;

io_error:
    fprintf(stderr, "  [%s] cannot save '%s': %s\n", __func__, filename, strerror(errno));

done:
    fclose(src);
    if (dst) {
        fclose(dst);
    }
    if (!ok) {
        unlink(temp_path);
    }
    return ok;
}

static int copy_config_value(char *dest, size_t size, const char *value)
{
    return copy_string(dest, size, value) && dest[0] && !strpbrk(dest, "\r\n") &&
           trim(dest) == dest && strlen(dest) == strlen(value);
}

static int encrypt_config_password(const char *policy, const char *password, char *encrypted, size_t size)
{
    return kmslib_encrypt(policy, password, encrypted, size) && encrypted[0] && !strpbrk(encrypted, "\r\n");
}

static int select_old_password(KMS_CREDENTIAL *cred, const KMS_CREDENTIAL *entry)
{
    wipe(cred->old_pwd, sizeof(cred->old_pwd));
    wipe(cred->old_pwd_enc, sizeof(cred->old_pwd_enc));
    cred->has_old = 0;

    if (!entry || strcmp(entry->user, cred->user) != 0) {
        return 0;
    }

    if (entry->has_new && strcmp(entry->new_pwd, cred->new_pwd) != 0) {
        memcpy(cred->old_pwd, entry->new_pwd, sizeof(cred->old_pwd));
        memcpy(cred->old_pwd_enc, entry->new_pwd_enc, sizeof(cred->old_pwd_enc));
        cred->has_old = 1;
    } else if (entry->has_old) {
        memcpy(cred->old_pwd, entry->old_pwd, sizeof(cred->old_pwd));
        memcpy(cred->old_pwd_enc, entry->old_pwd_enc, sizeof(cred->old_pwd_enc));
        cred->has_old = 1;
    }

    return cred->has_old && strcmp(entry->policy, cred->policy) != 0;
}

static int store_credential(const char *filename, const char *section, const char *user, const char *passwd,
                            const char *policy, int replace)
{
    SHM_KMS_CREDENTIAL *shm;
    KMS_CREDENTIAL *entry;
    KMS_CREDENTIAL cred = {0};
    char prepared_old_pwd[KMSLIB_PWD_SIZE];
    char prepared_old_enc[KMSLIB_ENC_SIZE] = {0};
    time_t now;
    int semid;
    int kms_active = 0;
    int old_prepared = 0;
    int ok = 0;

    if (!filename || !*filename || !copy_string(cred.section, sizeof(cred.section), section) ||
        !cred.section[0] || strpbrk(cred.section, "[]\r\n") ||
        !copy_config_value(cred.user, sizeof(cred.user), user) ||
        !copy_config_value(cred.policy, sizeof(cred.policy), policy) ||
        !copy_string(cred.new_pwd, sizeof(cred.new_pwd), passwd) || !cred.new_pwd[0]) {
        fprintf(stderr, "  [%s] invalid credential arguments\n", __func__);
        goto done;
    }

    while (1) {
        if (!attach_locked(&semid, &shm)) {
            fprintf(stderr, "  [%s] cannot attach to SHM\n", __func__);
            goto done;
        }

        if (!shm_is_ready(shm) || (!replace && shm->credential_count >= MAX_CREDENTIAL)) {
            fprintf(stderr, "  [%s] SHM is not ready or is full\n", __func__);
            goto detach;
        }

        entry = find_credential(shm, cred.section);
        if (replace && !entry) {
            fprintf(stderr, "  [%s] section [%s] is missing from SHM\n", __func__, cred.section);
            goto detach;
        }
        if (!replace && entry) {
            fprintf(stderr, "  [%s] section [%s] already exists in SHM\n", __func__, cred.section);
            goto detach;
        }

        if (!cred.has_new) {
            if (!detach_locked(semid, shm)) {
                goto done;
            }
            if (!kmslib_init()) {
                fprintf(stderr, "  [%s] KMS initialization failed\n", __func__);
                goto done;
            }
            kms_active = 1;
            if (!encrypt_config_password(cred.policy, cred.new_pwd, cred.new_pwd_enc, sizeof(cred.new_pwd_enc))) {
                fprintf(stderr, "  [%s] KMS encryption failed for section [%s], field PWD_ENC_NEW\n",
                        __func__, cred.section);
                goto done;
            }
            cred.has_new = 1;
            continue;
        }

        /* Select OLD from the latest entry each time the lock is reacquired. */
        if (select_old_password(&cred, entry)) {
            if (!old_prepared || strcmp(cred.old_pwd, prepared_old_pwd) != 0) {
                memcpy(prepared_old_pwd, cred.old_pwd, sizeof(prepared_old_pwd));
                if (!detach_locked(semid, shm)) {
                    goto done;
                }
                if (!encrypt_config_password(cred.policy, prepared_old_pwd, prepared_old_enc, sizeof(prepared_old_enc))) {
                    fprintf(stderr, "  [%s] KMS encryption failed for section [%s], field PWD_ENC_OLD\n",
                            __func__, cred.section);
                    goto done;
                }
                old_prepared = 1;
                continue;
            }
            memcpy(cred.old_pwd_enc, prepared_old_enc, sizeof(cred.old_pwd_enc));
        }

        break;
    }

    if (!check_config_target(filename, cred.section, replace)) {
        goto detach;
    }

    now = time(NULL);
    if (now == (time_t)-1) {
        fprintf(stderr, "  [%s] time() failed: %s\n", __func__, strerror(errno));
        goto detach;
    }

    if (!save_credential(filename, &cred, replace ? CREDENTIAL_CHANGE : CREDENTIAL_ADD, shm)) {
        goto detach;
    }

    if (!replace) {
        entry = &shm->credential[shm->credential_count];
        shm->credential_count++;
    }
    *entry = cred;
    shm->update_time = now;
    ok = 1;

detach:
    ok = detach_locked(semid, shm) && ok;
done:
    if (kms_active) {
        kmslib_cleanup();
    }
    kmslib_clear_credential(&cred);
    wipe(prepared_old_pwd, sizeof(prepared_old_pwd));
    wipe(prepared_old_enc, sizeof(prepared_old_enc));
    return ok;
}

int kmslib_add_credential(const char *section, const char *user, const char *passwd, const char *policy)
{
    return store_credential(kmslib_get_credential_file(), section, user, passwd, policy, 0);
}

int kmslib_change_credential(const char *section, const char *user, const char *passwd, const char *policy)
{
    return store_credential(kmslib_get_credential_file(), section, user, passwd, policy, 1);
}

int kmslib_delete_credential(const char *section)
{
    const char *filename = kmslib_get_credential_file();
    SHM_KMS_CREDENTIAL *shm;
    KMS_CREDENTIAL *entry;
    KMS_CREDENTIAL *last;
    time_t now;
    int semid;
    int ok = 0;

    if (!filename || !*filename || !section || !*section || strlen(section) >= KMSLIB_SECTION_SIZE ||
        strpbrk(section, "]\r\n")) {
        fprintf(stderr, "  [%s] invalid credential deletion arguments\n", __func__);
        return 0;
    }

    if (!attach_locked(&semid, &shm)) {
        fprintf(stderr, "  [%s] cannot attach to SHM\n", __func__);
        return 0;
    }

    if (!shm_is_ready(shm)) {
        fprintf(stderr, "  [%s] SHM is not ready\n", __func__);
        goto done;
    }

    entry = find_credential(shm, section);
    if (!entry) {
        fprintf(stderr, "  [%s] section [%s] is missing from SHM\n", __func__, section);
        goto done;
    }

    if (!check_config_target(filename, section, 1)) {
        goto done;
    }

    now = time(NULL);
    if (now == (time_t)-1) {
        fprintf(stderr, "  [%s] time() failed: %s\n", __func__, strerror(errno));
        goto done;
    }

    if (!save_credential(filename, entry, CREDENTIAL_DELETE, shm)) {
        goto done;
    }

    last = &shm->credential[shm->credential_count - 1];
    if (entry != last) {
        memmove(entry, entry + 1, (size_t)(last - entry) * sizeof(*entry));
    }
    kmslib_clear_credential(last);
    shm->credential_count--;
    shm->update_time = now;
    ok = 1;

done:
    return detach_locked(semid, shm) && ok;
}

int kmslib_get_password(const KMS_CREDENTIAL *cred, int attempt, char *out, size_t out_size)
{
    const char *src = NULL;

    if (!out || out_size == 0) {
        return 0;
    }
    wipe(out, out_size);
    if (!cred || (attempt != KMSLIB_TRY_NEW && attempt != KMSLIB_TRY_OLD)) {
        return 0;
    }

    if (attempt == KMSLIB_TRY_NEW) {
        if (cred->has_new && cred->new_pwd[0]) {
            src = cred->new_pwd;
        } else if (cred->has_old && cred->old_pwd[0]) {
            src = cred->old_pwd;
        }
    } else {
        if (cred->has_old && cred->old_pwd[0]) {
            src = cred->old_pwd;
        }
    }

    if (!src) {
        return 0;
    }

    return copy_string(out, out_size, src);
}

int kmslib_get_account_all(SHM_KMS_CREDENTIAL *shm, const char *section, char *user, size_t user_size,
                                char *passwd, size_t passwd_size, char *old_passwd, size_t old_passwd_size)
{
    const KMS_CREDENTIAL *entry;
    int semid;
    int ok = 0;

    if (user && user_size) {
        user[0] = '\0';
    }
    if (passwd && passwd_size) {
        wipe(passwd, passwd_size);
    }
    if (old_passwd && old_passwd_size) {
        wipe(old_passwd, old_passwd_size);
    }
    if (!shm || !section || !*section || !user || !user_size || !passwd || !passwd_size ||
        (old_passwd && !old_passwd_size)) {
        fprintf(stderr, "  [%s] invalid SHM account lookup arguments\n", __func__);
        return 0;
    }

    semid = lock_shm();
    if (semid < 0) {
        return 0;
    }

    if (!shm_is_ready(shm)) {
        fprintf(stderr, "  [%s] SHM is not ready\n", __func__);
        goto done;
    }

    entry = find_credential(shm, section);
    if (!entry) {
        fprintf(stderr, "  [%s] section [%s] is missing from SHM\n", __func__, section);
        goto done;
    }

    if (!kmslib_get_password(entry, KMSLIB_TRY_NEW, passwd, passwd_size) ||
        !copy_string(user, user_size, entry->user)) {
        fprintf(stderr, "  [%s] missing password or short buffer for section [%s]\n", __func__, section);
        goto done;
    }

    if (old_passwd && entry->has_old && entry->old_pwd[0] &&
        !kmslib_get_password(entry, KMSLIB_TRY_OLD, old_passwd, old_passwd_size)) {
        fprintf(stderr, "  [%s] OLD password buffer is too small for section [%s]\n", __func__, section);
        goto done;
    }
    ok = 1;

done:
    ok = unlock_shm(semid) && ok;
    if (!ok) {
        user[0] = '\0';
        wipe(passwd, passwd_size);
        if (old_passwd) {
            wipe(old_passwd, old_passwd_size);
        }
    }
    return ok;
}

int kmslib_get_account(SHM_KMS_CREDENTIAL *shm, const char *section, int attempt, char *user, size_t user_size,
                       char *passwd, size_t passwd_size)
{
    const KMS_CREDENTIAL *entry;
    const char *selected = NULL;
    int semid;
    int ok = 0;

    if (user && user_size) {
        user[0] = '\0';
    }
    if (passwd && passwd_size) {
        wipe(passwd, passwd_size);
    }

    if (!shm || !section || !*section || !user || !user_size || !passwd || !passwd_size ||
        (attempt != KMSLIB_TRY_NEW && attempt != KMSLIB_TRY_OLD)) {
        fprintf(stderr, "  [%s] invalid SHM account lookup arguments\n", __func__);
        return 0;
    }

    semid = lock_shm();
    if (semid < 0) {
        return 0;
    }

    if (!shm_is_ready(shm)) {
        fprintf(stderr, "  [%s] SHM is not ready\n", __func__);
        goto done;
    }

    entry = find_credential(shm, section);
    if (!entry) {
        fprintf(stderr, "  [%s] section [%s] is missing from SHM\n", __func__, section);
        goto done;
    }

    if (attempt == KMSLIB_TRY_NEW && entry->has_new) {
        selected = entry->new_pwd;
    } else if (attempt == KMSLIB_TRY_OLD && entry->has_old) {
        selected = entry->old_pwd;
    }

    if (!selected || !*selected || !copy_string(passwd, passwd_size, selected) ||
        !copy_string(user, user_size, entry->user)) {
        fprintf(stderr, "  [%s] missing password or short buffer for section [%s]\n", __func__, section);
        goto done;
    }

    ok = 1;

done:
    ok = unlock_shm(semid) && ok;
    if (!ok) {
        user[0] = '\0';
        wipe(passwd, passwd_size);
    }
    return ok;
}
