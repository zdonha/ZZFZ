#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "kmslib.h"
#include "lguplus_kms_client.h"

static int kms_initialized = 0;
static const char kms_credential_file[] = "./kms_credential.conf";

const char *kmslib_get_credential_file(void)
{
    return kms_credential_file;
}

static void print_kms_properties(void)
{
    FILE *fp;
    char *line = NULL;
    size_t capacity = 0;
    char *key;
    char *separator;

    fp = fopen(KMSLIB_PROPERTIES_FILE, "r");
    if (!fp) {
        fprintf(stderr, "  [%s] cannot open kms.properties: %s\n", __func__, strerror(errno));
        return;
    }

    while (getline(&line, &capacity, fp) >= 0) {
        line[strcspn(line, "\r\n")] = '\0';
        key = line + strspn(line, " \t");
        separator = strchr(key, '=');
        if (!separator || separator == key || *key == '#' || *key == ';') {
            continue;
        }

        fprintf(stderr, "  [%s] %s\n", __func__, line);
    }

    if (ferror(fp)) {
        fprintf(stderr, "  [%s] cannot read kms.properties: %s\n", __func__, strerror(errno));
    }
    free(line);
    fclose(fp);
}

int kmslib_init(void)
{
    if (!kms_initialized) {
        print_kms_properties();
        lguplus_kms_init();
        kms_initialized = 1;
    }

    return 1;
}

void kmslib_cleanup(void)
{
    if (kms_initialized) {
        lguplus_kms_cleanup();
        kms_initialized = 0;
    }
}

int reload_kms_properties(void)
{
    kmslib_cleanup();
    return kmslib_init();
}

int kmslib_encrypt(const char *policy, const char *data, char *out, size_t out_size)
{
    LguplusKmsResult res;
    size_t len;
    int result = 0;

    if (out == NULL || out_size == 0) {
        return 0;
    }

    out[0] = '\0';
    if (policy == NULL || data == NULL) {
        return 0;
    }

    fprintf(stderr, "  [%s] encrypt request attempt\n", __func__);
    res = lguplus_kms_encrypt(policy, data);
    if (res.success && res.data != NULL) {
        len = strlen(res.data);
        if (len < out_size) {
            memcpy(out, res.data, len + 1);
            result = 1;
        }
    }

    if (res.data != NULL) {
        free(res.data);
    }

    fprintf(stderr, "  [%s] encrypt request result: sdk_success=%d result=%d\n", __func__, res.success, result);
    return result;
}

/*
 * return : 1=성공, 0=실패
 * out    : 복호화 결과(평문)
 */
int kmslib_decrypt(const char *policy, const char *b64_data, char *out, size_t out_size)
{
    LguplusKmsResult res;
    size_t len;
    int result = 0;

    if (out == NULL || out_size == 0) {
        return 0;
    }

    out[0] = '\0';
    if (policy == NULL || b64_data == NULL) {
        return 0;
    }

    fprintf(stderr, "  [%s] decrypt request attempt\n", __func__);
    res = lguplus_kms_decrypt(policy, b64_data);
    if (res.success && res.data != NULL) {
        len = strlen(res.data);
        if (len > 0 && len < out_size) {
            memcpy(out, res.data, len + 1);
            result = 1;
        }
    }

    if (res.data != NULL) {
        free(res.data);
    }

    fprintf(stderr, "  [%s] decrypt request result: sdk_success=%d result=%d\n", __func__, res.success, result);
    return result;
}
