#define _POSIX_C_SOURCE 200809L
#include "kmslib.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <unistd.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

#define KEY_SIZE 32
#define NONCE_SIZE 12
#define TAG_SIZE 16
#define HEADER_SIZE (4 + NONCE_SIZE + TAG_SIZE)
#define MAX_PAYLOAD (KMS_CACHE_MAX * sizeof(KmsCredential))
#define MAX_PASSWORD_BYTES (KMS_CACHE_MAX * KMS_PWD_SIZE)

typedef struct {
    char section[KMS_SECTION_SIZE];
    char id[KMS_ID_SIZE];
} CacheNames;

/* KMC2 | nonce[12] | tag[16] | names[count] | encrypted passwords[count].
 * Names are plaintext and authenticated as GCM additional data.
 * Count follows from file size. All persisted fields are byte arrays.
 */
static const unsigned char magic[4] = {'K', 'M', 'C', '2'};

static int read_file(const char *path, unsigned char *data, size_t capacity,
                     size_t *size)
{
    FILE *fp;
    int ok;

    fp = fopen(path, "rb");
    if (fp == NULL) {
        return 0;
    }
    *size = fread(data, 1, capacity, fp);
    ok = !ferror(fp) && fgetc(fp) == EOF && !ferror(fp);
    if (fclose(fp) != 0) {
        ok = 0;
    }
    return ok;
}

static int write_file(int fd, const unsigned char *data, size_t size)
{
    ssize_t n;

    while (size > 0) {
        n = write(fd, data, size);
        if (n < 0 && errno == EINTR) {
            continue;
        }
        if (n <= 0) {
            return 0;
        }
        data += n;
        size -= (size_t)n;
    }
    return fsync(fd) == 0;
}

static int read_key(const char *path, unsigned char *key)
{
    size_t size;

    return read_file(path, key, KEY_SIZE, &size) && size == KEY_SIZE;
}

static int valid_items(const KmsCredential *items, size_t count)
{
    size_t i;
    size_t j;

    for (i = 0; i < count; i++) {
        if (items[i].section[0] == '\0' || items[i].id[0] == '\0' ||
            items[i].pwd[0] == '\0' ||
            memchr(items[i].section, '\0', KMS_SECTION_SIZE) == NULL ||
            memchr(items[i].id, '\0', KMS_ID_SIZE) == NULL ||
            memchr(items[i].pwd, '\0', KMS_PWD_SIZE) == NULL) {
            return 0;
        }
        for (j = 0; j < i; j++) {
            if (strcmp(items[i].section, items[j].section) == 0) {
                return 0;
            }
        }
    }
    return 1;
}

void kms_cache_clear(KmsCredential *items, size_t count)
{
    if (items != NULL) {
        OPENSSL_cleanse(items, count * sizeof(*items));
    }
}

int kms_cache_create_key(const char *key_path)
{
    unsigned char key[KEY_SIZE];
    int fd;
    int ok;

    if (RAND_bytes(key, sizeof(key)) != 1) {
        OPENSSL_cleanse(key, sizeof(key));
        return 0;
    }
    fd = open(key_path, O_WRONLY | O_CREAT | O_EXCL, 0600);
    ok = 0;
    if (fd >= 0) {
        ok = write_file(fd, key, sizeof(key));
        if (close(fd) != 0) {
            ok = 0;
        }
        if (!ok) {
            unlink(key_path);
        }
    }
    OPENSSL_cleanse(key, sizeof(key));
    return ok;
}

int kms_cache_write(const char *key_path, const char *cache_path,
                   const KmsCredential *items, size_t count)
{
    unsigned char key[KEY_SIZE] = {0};
    unsigned char *output;
    unsigned char *passwords;
    CacheNames *names;
    EVP_CIPHER_CTX *ctx;
    struct stat key_stat;
    struct stat cache_stat;
    char *temporary;
    size_t payload;
    size_t names_size;
    size_t password_size;
    size_t i;
    int n;
    int last;
    int fd;
    int ok;

    if (items == NULL || count > KMS_CACHE_MAX ||
        !valid_items(items, count)) {
        return 0;
    }
    /* Never overwrite the key, including an existing hard/symbolic link. */
    if (strcmp(key_path, cache_path) == 0 || stat(key_path, &key_stat) != 0 ||
        (stat(cache_path, &cache_stat) == 0 &&
         key_stat.st_dev == cache_stat.st_dev && key_stat.st_ino == cache_stat.st_ino)) {
        return 0;
    }
    payload = count * sizeof(*items);
    names_size = count * sizeof(CacheNames);
    password_size = count * KMS_PWD_SIZE;
    output = calloc(1, HEADER_SIZE + payload + EVP_MAX_BLOCK_LENGTH);
    passwords = calloc(1, password_size + 1);
    temporary = malloc(strlen(cache_path) + sizeof(".tmp.XXXXXX"));
    ctx = EVP_CIPHER_CTX_new();
    ok = 0;
    if (output != NULL && passwords != NULL && temporary != NULL &&
        ctx != NULL && read_key(key_path, key)) {
        memcpy(output, magic, sizeof(magic));
        names = (CacheNames *)(output + HEADER_SIZE);
        for (i = 0; i < count; i++) {
            strcpy(names[i].section, items[i].section);
            strcpy(names[i].id, items[i].id);
            strcpy((char *)passwords + i * KMS_PWD_SIZE, items[i].pwd);
        }
        ok = RAND_bytes(output + 4, NONCE_SIZE) == 1 &&
             EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, output + 4) == 1 &&
             EVP_EncryptUpdate(ctx, NULL, &n, output, 4) == 1 &&
             EVP_EncryptUpdate(ctx, NULL, &n, output + HEADER_SIZE, (int)names_size) == 1 &&
             EVP_EncryptUpdate(ctx, output + HEADER_SIZE + names_size, &n,
                               passwords, (int)password_size) == 1 &&
             EVP_EncryptFinal_ex(ctx, output + HEADER_SIZE + names_size + n, &last) == 1 &&
             EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, TAG_SIZE,
                                 output + 4 + NONCE_SIZE) == 1;
        if (ok) {
            sprintf(temporary, "%s.tmp.XXXXXX", cache_path);
            fd = mkstemp(temporary); /* 0600, same directory as cache. */
            ok = fd >= 0;
            if (fd >= 0) {
                ok = write_file(fd, output,
                                HEADER_SIZE + names_size + (size_t)n + (size_t)last);
                if (close(fd) != 0) {
                    ok = 0;
                }
                if (ok) {
                    ok = rename(temporary, cache_path) == 0;
                }
                if (!ok) {
                    unlink(temporary);
                }
            }
        }
    }
    OPENSSL_cleanse(key, sizeof(key));
    EVP_CIPHER_CTX_free(ctx);
    if (passwords != NULL) {
        OPENSSL_cleanse(passwords, password_size);
    }
    free(passwords);
    free(temporary);
    free(output);
    return ok;
}

int kms_cache_read(const char *key_path, const char *cache_path,
                   KmsCredential *items, size_t capacity, size_t *count)
{
    unsigned char key[KEY_SIZE] = {0};
    unsigned char *input;
    KmsCredential *plain;
    unsigned char *passwords;
    const CacheNames *names;
    unsigned char final_buffer[EVP_MAX_BLOCK_LENGTH];
    EVP_CIPHER_CTX *ctx;
    size_t size;
    size_t payload;
    size_t records;
    size_t names_size;
    size_t password_size;
    size_t i;
    int n;
    int last;
    int ok;

    if (count == NULL) {
        return 0;
    }
    *count = 0;
    if (items == NULL || capacity == 0 || capacity > KMS_CACHE_MAX) {
        return 0;
    }
    kms_cache_clear(items, capacity);
    input = malloc(HEADER_SIZE + MAX_PAYLOAD);
    plain = calloc(KMS_CACHE_MAX, sizeof(*plain));
    passwords = calloc(1, MAX_PASSWORD_BYTES);
    ctx = EVP_CIPHER_CTX_new();
    ok = 0;
    if (input != NULL && plain != NULL && passwords != NULL &&
        ctx != NULL && read_key(key_path, key) &&
        read_file(cache_path, input, HEADER_SIZE + MAX_PAYLOAD, &size) &&
        size >= HEADER_SIZE &&
        (memcmp(input, magic, sizeof(magic)) == 0 || memcmp(input, "KMC1", 4) == 0)) {
        payload = size - HEADER_SIZE;
        records = payload / sizeof(*items);
        if (payload % sizeof(*items) == 0 && records <= capacity) {
            names_size = records * sizeof(CacheNames);
            password_size = records * KMS_PWD_SIZE;
            names = (const CacheNames *)(input + HEADER_SIZE);
            if (memcmp(input, "KMC1", 4) == 0) {
                /* Read old all-encrypted caches; the next write uses KMC2. */
                ok = EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, input + 4) == 1 &&
                     EVP_DecryptUpdate(ctx, (unsigned char *)plain, &n,
                                       input + HEADER_SIZE, (int)payload) == 1 &&
                     EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, TAG_SIZE,
                                         input + 4 + NONCE_SIZE) == 1 &&
                     EVP_DecryptFinal_ex(ctx, final_buffer, &last) == 1 &&
                     n == (int)payload && last == 0;
            } else {
                ok = EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, input + 4) == 1 &&
                     EVP_DecryptUpdate(ctx, NULL, &n, input, 4) == 1 &&
                     EVP_DecryptUpdate(ctx, NULL, &n, input + HEADER_SIZE, (int)names_size) == 1 &&
                     EVP_DecryptUpdate(ctx, passwords, &n,
                                       input + HEADER_SIZE + names_size, (int)password_size) == 1 &&
                     EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, TAG_SIZE,
                                         input + 4 + NONCE_SIZE) == 1 &&
                     EVP_DecryptFinal_ex(ctx, final_buffer, &last) == 1 &&
                     n == (int)password_size && last == 0;
                if (ok) {
                    for (i = 0; i < records; i++) {
                        memcpy(plain[i].section, names[i].section, KMS_SECTION_SIZE);
                        memcpy(plain[i].id, names[i].id, KMS_ID_SIZE);
                        memcpy(plain[i].pwd, passwords + i * KMS_PWD_SIZE, KMS_PWD_SIZE);
                    }
                }
            }
            ok = ok && valid_items(plain, records);
            if (ok) {
                memcpy(items, plain, payload);
                *count = records;
            }
        }
    }
    OPENSSL_cleanse(key, sizeof(key));
    kms_cache_clear(plain, KMS_CACHE_MAX);
    if (passwords != NULL) {
        OPENSSL_cleanse(passwords, MAX_PASSWORD_BYTES);
    }
    free(passwords);
    free(plain);
    free(input);
    EVP_CIPHER_CTX_free(ctx);
    return ok;
}


/* Each call opens its own lock description, serializing processes and threads.
 * Keep the lock file in place; deleting it would create separate lock domains.
 */
static int cache_lock(int operation)
{
    const char *base;
    char *lock_path;
    size_t directory_size;
    int fd;

    base = strrchr(KMS_CACHE_FILE_PATH, '/');
    directory_size = base ? (size_t)(base - KMS_CACHE_FILE_PATH + 1) : 0;
    lock_path = malloc(strlen(KMS_CACHE_FILE_PATH) + sizeof("..lock"));
    if (!lock_path) {
        return -1;
    }
    memcpy(lock_path, KMS_CACHE_FILE_PATH, directory_size);
    sprintf(lock_path + directory_size, ".%s.lock", KMS_CACHE_FILE_PATH + directory_size);
    fd = open(lock_path, O_RDWR | O_CREAT, 0600);
    free(lock_path);
    if (fd < 0) {
        return -1;
    }
    while (flock(fd, operation) != 0) {
        if (errno != EINTR) {
            close(fd);
            return -1;
        }
    }
    return fd;
}

static void cache_unlock(int fd)
{
    /* Closing the descriptor releases its flock lock. */
    close(fd);
}

int kms_cache_init(void)
{
    struct stat info;
    int fd;
    int ok;

    fd = cache_lock(LOCK_EX);
    if (fd < 0) {
        return 0;
    }
    ok = 0;
    if (lstat(KMS_CACHE_KEY_PATH, &info) == 0) {
        fprintf(stderr, "  Key already exists; unchanged: %s\n", KMS_CACHE_KEY_PATH);
    } else if (errno == ENOENT) {
        ok = kms_cache_create_key(KMS_CACHE_KEY_PATH);
    }
    cache_unlock(fd);
    if (!ok) {
        fprintf(stderr, "  Key creation failed: %s\n", KMS_CACHE_KEY_PATH);
    }
    return ok;
}

static int cache_display(int show_password)
{
    KmsCredential cred[KMS_CACHE_MAX] = {0};
    size_t count;
    size_t i;
    int fd;
    int ok;

    fd = cache_lock(LOCK_SH);
    if (fd < 0) {
        return 0;
    }
    ok = kms_cache_read(KMS_CACHE_KEY_PATH, KMS_CACHE_FILE_PATH,
                        cred, KMS_CACHE_MAX, &count);
    cache_unlock(fd);
    if (!ok) {
        fprintf(stderr, "  Cache load failed: %s\n", KMS_CACHE_FILE_PATH);
        return 0;
    }
    /* Always authenticate the complete cache before displaying any entry. */
    for (i = 0; i < count; i++) {
        if (printf("  SECTION=%s USER=%s PWD=%s\n",
                   cred[i].section, cred[i].id, show_password ? cred[i].pwd : "********") < 0) {
            ok = 0;
            break;
        }
    }
    if (ok && printf("  %s %zu credential(s).\n", show_password ? "Loaded" : "Total", count) < 0) {
        ok = 0;
    }
    if (fflush(stdout) != 0) {
        ok = 0;
    }
    kms_cache_clear(cred, KMS_CACHE_MAX);
    return ok;
}

int kms_cache_load(void)
{
    return cache_display(1);
}

int kms_cache_view(void)
{
    return cache_display(0);
}

int kms_cache_save(char *section, char *user, char *passwd)
{
    KmsCredential cred[KMS_CACHE_MAX] = {0};
    struct stat info;
    size_t count;
    size_t slot;
    size_t i;
    int fd;
    int ok;

    if (section == NULL || user == NULL || passwd == NULL ||
        section[0] == '\0' || user[0] == '\0' || passwd[0] == '\0' ||
        strlen(section) >= KMS_SECTION_SIZE || strlen(user) >= KMS_ID_SIZE ||
        strlen(passwd) >= KMS_PWD_SIZE) {
        fprintf(stderr, "  Invalid credential or field length.\n");
        return 0;
    }
    fd = cache_lock(LOCK_EX);
    if (fd < 0) {
        return 0;
    }
    count = 0;
    ok = 0;
    if (lstat(KMS_CACHE_FILE_PATH, &info) == 0) {
        if (!kms_cache_read(KMS_CACHE_KEY_PATH, KMS_CACHE_FILE_PATH,
                            cred, KMS_CACHE_MAX, &count)) {
            fprintf(stderr, "  Existing cache is invalid; save cancelled.\n");
            goto done;
        }
    } else if (errno != ENOENT) {
        goto done;
    }
    slot = count;
    for (i = 0; i < count; i++) {
        if (strcmp(cred[i].section, section) == 0) {
            slot = i;
            break;
        }
    }
    if (slot == KMS_CACHE_MAX) {
        fprintf(stderr, "  Cache is full (maximum %d sections).\n", KMS_CACHE_MAX);
        goto done;
    }
    kms_cache_clear(&cred[slot], 1);
    strcpy(cred[slot].section, section);
    strcpy(cred[slot].id, user);
    strcpy(cred[slot].pwd, passwd);
    if (slot == count) {
        count++;
    }
    ok = kms_cache_write(KMS_CACHE_KEY_PATH, KMS_CACHE_FILE_PATH, cred, count);
done:
    kms_cache_clear(cred, KMS_CACHE_MAX);
    cache_unlock(fd);
    if (!ok) {
        fprintf(stderr, "  Cache save failed: %s\n", KMS_CACHE_FILE_PATH);
    }
    return ok;
}

static int delete_matching(const char *section, const KmsCredential *expected)
{
    KmsCredential cred[KMS_CACHE_MAX] = {0};
    size_t count;
    size_t i;
    int fd;
    int ok;

    if (section == NULL || section[0] == '\0' || strlen(section) >= KMS_SECTION_SIZE) {
        fprintf(stderr, "  Invalid SECTION.\n");
        return 0;
    }
    fd = cache_lock(LOCK_EX);
    if (fd < 0) {
        return 0;
    }
    ok = 0;
    if (!kms_cache_read(KMS_CACHE_KEY_PATH, KMS_CACHE_FILE_PATH,
                        cred, KMS_CACHE_MAX, &count)) {
        goto done;
    }
    for (i = 0; i < count; i++) {
        if (strcmp(cred[i].section, section) == 0) {
            break;
        }
    }
    if (i == count) {
        fprintf(stderr, "  SECTION not found: %s\n", section);
        goto done;
    }
    if (expected && (strcmp(cred[i].id, expected->id) != 0 ||
                     strcmp(cred[i].pwd, expected->pwd) != 0)) {
        fprintf(stderr, "  Account changed after confirmation; retry the command.\n");
        goto done;
    }
    memmove(&cred[i], &cred[i + 1], (count - i - 1) * sizeof(*cred));
    count--;
    kms_cache_clear(&cred[count], 1);
    ok = kms_cache_write(KMS_CACHE_KEY_PATH, KMS_CACHE_FILE_PATH, cred, count);
done:
    kms_cache_clear(cred, KMS_CACHE_MAX);
    cache_unlock(fd);
    if (!ok) {
        fprintf(stderr, "  Cache delete failed.\n");
    }
    return ok;
}

int kms_cache_delete(char *section)
{
    return delete_matching(section, NULL);
}

int kms_cache_delete_if_unchanged(const KmsCredential *expected)
{
    if (!expected || !valid_items(expected, 1)) {
        return 0;
    }
    return delete_matching(expected->section, expected);
}
