#ifndef __KMSLIB_H__
#define __KMSLIB_H__

#include <stddef.h>
#include <stdint.h>
#include <time.h>

#define MAX_CREDENTIAL       16
#define KMSLIB_SECTION_SIZE 32
#define KMSLIB_USER_SIZE    64
#define KMSLIB_POLICY_SIZE  64
#define KMSLIB_ENC_SIZE    512
#define KMSLIB_PWD_SIZE    512

/*
 * NEW first; OLD is used only after a definite authentication rejection.
 * The application (DB/FTP client) must decide whether to retry.
 */
#define KMSLIB_TRY_NEW      0
#define KMSLIB_TRY_OLD      1

typedef struct {
    char section[KMSLIB_SECTION_SIZE];
    char policy[KMSLIB_POLICY_SIZE];
    char user[KMSLIB_USER_SIZE];

    /* Original encrypted values, for rotation/diagnostics only. */
    char new_pwd_enc[KMSLIB_ENC_SIZE];
    char old_pwd_enc[KMSLIB_ENC_SIZE];

    /* Decrypted passwords held in SHM: never log these fields. */
    char new_pwd[KMSLIB_PWD_SIZE];
    char old_pwd[KMSLIB_PWD_SIZE];
    int has_new;	// Zao... -> tobe deleted
    int has_old;	// Zao... -> tobe deleted
} KMS_CREDENTIAL;

typedef struct {
    uint32_t reserved[3];  /* Preserve the layout of existing SHM segments. */
    time_t kms_link_time;  /* NO NEED - Last successful KMS decryption batch. */
    time_t update_time;    /* Last successful SHM data update. */
    time_t expire_time;    /* NO NEED - Reserved; NOT checked by current implementation. */
    int credential_count;
    KMS_CREDENTIAL credential[MAX_CREDENTIAL];
} SHM_KMS_CREDENTIAL;

/* Set the package working directory before using KMS APIs. Both configuration files are resolved there. */
#define KMSLIB_PROPERTIES_FILE "kms.properties"

int kmslib_init(void);
int reload_kms_properties(void);
void kmslib_cleanup(void);
int kmslib_encrypt(const char *policy, const char *data, char *out, size_t out_size);
int kmslib_decrypt(const char *policy, const char *b64_data, char *out, size_t out_size);
const char *kmslib_get_credential_file(void);
/* Set once at startup, before any SHM operation or worker threads. */
int kmslib_set_shm_key(long key);
/* Status snapshots deliberately contain no password or ciphertext fields. */
typedef struct {
    char section[KMSLIB_SECTION_SIZE];
    char policy[KMSLIB_POLICY_SIZE];
    char user[KMSLIB_USER_SIZE];
    int has_new;
    int has_old;
} KMS_CREDENTIAL_INFO;

typedef struct {
    long key;
    int exists;
    int shmid;
    size_t size;
    unsigned long attachments;
    int ready;
    int credential_count;
    time_t update_time;
    time_t kms_link_time;
    time_t expire_time;
    uint32_t reserved[3];
    KMS_CREDENTIAL_INFO credential[MAX_CREDENTIAL];
} KMS_SHM_STATUS;

/* No KMS calls. Restore validates the cache before replacing SHM.
 * Existing SHM must have no attached processes. Status never creates SHM.
 */
int kmslib_restore_local_cache(void);
int kmslib_get_shm_status(KMS_SHM_STATUS *status);
/* Pass a NULL-initialized handle. The credential file is read if SHM needs initialization. */
int kmslib_load_credential(SHM_KMS_CREDENTIAL **shm);
/* Detach the caller's handle. Other processes can continue using the segment. */
int kmslib_detach_credential(SHM_KMS_CREDENTIAL **shm);
int kmslib_reload_credentials(void);
int kmslib_get_shm_snapshot(const SHM_KMS_CREDENTIAL *shm, SHM_KMS_CREDENTIAL *snapshot);
int kmslib_add_credential(const char *section, const char *user, const char *passwd, const char *policy);
int kmslib_change_credential(const char *section, const char *user, const char *passwd, const char *policy);
int kmslib_delete_credential(const char *section);
/* Account lookups copy into caller-owned buffers. Clear them with kmslib_clear_buffer() after use.
 * Try the optional OLD password once after a definite authentication rejection.
 */
/* Fetch only the requested NEW or OLD password. Returns 0 if unavailable or attempt is invalid. */
int kmslib_get_account(SHM_KMS_CREDENTIAL *shm, const char *section, int attempt, char *user, size_t user_size,
                       char *passwd, size_t passwd_size);
int kmslib_get_account_all(SHM_KMS_CREDENTIAL *shm, const char *section, char *user, size_t user_size,
                                char *passwd, size_t passwd_size, char *old_passwd, size_t old_passwd_size);
int kmslib_get_password(const KMS_CREDENTIAL *cred, int attempt, char *out, size_t out_size);
void kmslib_clear_buffer(void *buffer, size_t size);
void kmslib_clear_credential(KMS_CREDENTIAL *cred);

/* Local recovery cache: SECTION/USER plaintext, PWD encrypted (AES-256-GCM). */
#define KMS_CACHE_MAX 10
#define KMS_SECTION_SIZE 64
#define KMS_ID_SIZE 64
#define KMS_PWD_SIZE 4097

/* Use the same package directory in kms_load and mmib, or set absolute paths. */
#ifndef KMS_CACHE_KEY_PATH
#define KMS_CACHE_KEY_PATH "kms_cache.key"
#endif
#ifndef KMS_CACHE_FILE_PATH
#define KMS_CACHE_FILE_PATH "kms_credential.cache"
#endif

typedef struct {
    char section[KMS_SECTION_SIZE];
    char id[KMS_ID_SIZE];
    char pwd[KMS_PWD_SIZE];
} KmsCredential;

/* Return 1 on success, 0 on failure. Existing keys are never overwritten.
 * init/save/delete/load serialize through a persistent .cache.lock file.
 * save: upsert by SECTION. delete: fail if SECTION is absent.
 * load: diagnostic output, including plaintext passwords; no SHM handling.
 */
int kms_cache_init(void);
int kms_cache_save(char *section, char *user, char *passwd);
int kms_cache_delete(char *section);
/* Delete only if the displayed account still matches the current cache. */
int kms_cache_delete_if_unchanged(const KmsCredential *expected);
int kms_cache_load(void);
/* Display SECTION/USER and a fixed mask; never print plaintext passwords. */
int kms_cache_view(void);

/* Array APIs for callers that need memory data without diagnostic output.
 * read: failure clears the supplied array and sets count to zero.
 * write replaces the complete cache; zero records is supported.
 * Callers doing read/modify/write with these low-level APIs must serialize it.
 */
int kms_cache_create_key(const char *key_path);
int kms_cache_read(const char *key_path, const char *cache_path,
                   KmsCredential *items, size_t capacity, size_t *count);
int kms_cache_write(const char *key_path, const char *cache_path,
                    const KmsCredential *items, size_t count);
void kms_cache_clear(KmsCredential *items, size_t count);

#endif
