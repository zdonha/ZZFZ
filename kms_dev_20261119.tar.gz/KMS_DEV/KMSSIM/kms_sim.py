import argparse
import configparser
import json
import math
import ssl
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

BASE_DIR = Path(__file__).resolve().parent
LOGIN_PATH = "/api/auth/login/basic"
KEY_PATH = "/api/exportKey/by/name/"


class Handler(BaseHTTPRequestHandler):
    def respond(self, status, payload):
        # The vendor SDK searches for the exact substring '"value":"'.
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self.close_connection = True

        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            self.log_message("client disconnected before receiving the response")

    def fail(self, status, message):
        self.respond(status, {"success": False, "error": message})

    def do_POST(self):
        if urlsplit(self.path).path != LOGIN_PATH:
            self.fail(404, "Not Found")
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.fail(400, "Invalid Content-Length")
            return

        if not 0 <= length <= 65536:
            self.fail(400, "Invalid request size")
            return

        if len(self.rfile.read(length)) != length:
            self.fail(400, "Incomplete request body")
            return

        time.sleep(self.server.options.login_delay)
        if self.server.options.login_fail:
            self.fail(401, "Login rejected")
            return

        self.respond(200, self.server.login_response)

    def do_GET(self):
        path = urlsplit(self.path).path
        if not path.startswith(KEY_PATH):
            self.fail(404, "Not Found")
            return

        time.sleep(self.server.options.key_delay)
        token = self.server.login_response["value"]
        if self.server.options.token_fail or self.headers.get("Authorization") != f"Bearer {token}":
            self.fail(401, "Missing or invalid token")
            return

        policy = unquote(path[len(KEY_PATH):])
        key = self.server.keys.get(policy)
        if key is None:
            self.fail(404, "Unknown policy")
            return

        if self.server.options.key_fail:
            self.fail(503, "Key lookup unavailable")
            return

        self.respond(200, {"success": True, "value": key})


def delay_seconds(value):
    try:
        seconds = float(value)
    except ValueError:
        raise argparse.ArgumentTypeError("delay must be a non-negative number") from None

    if not math.isfinite(seconds) or seconds < 0:
        raise argparse.ArgumentTypeError("delay must be a finite, non-negative number")
    return seconds


def load_config():
    config = configparser.ConfigParser(interpolation=None)
    config.optionxform = str
    with (BASE_DIR / "kmssim.conf").open(encoding="utf-8") as source:
        config.read_file(source)

    if "kmssim" not in config or "keys" not in config or not config["keys"]:
        raise ValueError("expected [kmssim] and at least one policy in [keys]")

    keys = {}
    for policy, value in config["keys"].items():
        try:
            key = bytes.fromhex(value)
        except ValueError:
            raise ValueError(f"invalid hex key for policy {policy}") from None
        if len(key) != 32:
            raise ValueError(f"policy {policy} requires a 32-byte key")
        keys[policy] = key.hex()

    return config["kmssim"], keys


def main():
    parser = argparse.ArgumentParser(description="Local HTTPS simulator for the KMS SDK")
    parser.add_argument("--port", type=int)
    parser.add_argument("--login-fail", action=argparse.BooleanOptionalAction, help="reject login with HTTP 401")
    parser.add_argument("--token-fail", action=argparse.BooleanOptionalAction, help="reject key access with HTTP 401")
    parser.add_argument("--key-fail", action=argparse.BooleanOptionalAction, help="fail known key lookups with HTTP 503")
    parser.add_argument("--login-delay", type=delay_seconds, metavar="SECONDS")
    parser.add_argument("--key-delay", type=delay_seconds, metavar="SECONDS")
    options = parser.parse_args()

    try:
        settings, keys = load_config()
        if options.port is None:
            options.port = settings.getint("port", fallback=9443)
        for option in ("login_fail", "token_fail", "key_fail"):
            if getattr(options, option) is None:
                setattr(options, option, settings.getboolean(option, fallback=False))
        for option in ("login_delay", "key_delay"):
            if getattr(options, option) is None:
                setattr(options, option, delay_seconds(settings.get(option, fallback="0")))
    except (OSError, ValueError, configparser.Error, argparse.ArgumentTypeError) as error:
        parser.error(f"kmssim.conf: {error}")

    if not 1 <= options.port <= 65535:
        parser.error("port must be between 1 and 65535")

    with (BASE_DIR / "login_response.json").open(encoding="utf-8") as source:
        login_response = json.load(source)

    token = login_response.get("value")
    if login_response.get("success") is not True or not isinstance(token, str) or not token:
        parser.error("login_response.json must contain success=true and a non-empty token")

    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(BASE_DIR / "server.crt", BASE_DIR / "server.key")

    with ThreadingHTTPServer(("127.0.0.1", options.port), Handler) as server:
        server.options = options
        server.login_response = login_response
        server.keys = keys

        server.socket = context.wrap_socket(server.socket, server_side=True)
        print(f"KMS HTTPS SIM SERVER LISTEN {options.port}", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
