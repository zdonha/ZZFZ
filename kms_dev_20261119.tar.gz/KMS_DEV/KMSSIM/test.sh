#!/bin/bash

set -o pipefail

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 1
if [[ -n "${KMSSIM_URL:-}" ]]; then
    URL="$KMSSIM_URL"
else
    PORT=$(python3 - "$script_dir/kmssim.conf" <<'PY'
import configparser
import sys

config = configparser.ConfigParser(interpolation=None)
config.optionxform = str
try:
    with open(sys.argv[1], encoding="utf-8") as source:
        config.read_file(source)
    port = config["kmssim"].getint("port", fallback=9443)
    if not 1 <= port <= 65535:
        raise ValueError("port must be between 1 and 65535")
except (OSError, KeyError, ValueError, configparser.Error) as error:
    sys.exit(f"kmssim.conf: {error}")
print(port)
PY
    ) || exit $?
    URL="https://127.0.0.1:$PORT"
fi
AGENT="${KMSSIM_AGENT:-RCSG_01}"
POLICY="${2:-${KMSSIM_POLICY:-DEV_01}}"
CURL_OPT=(-ksS --connect-timeout 3 --max-time "${KMSSIM_TIMEOUT:-10}")

post()
{
    local body
    body=$(python3 -c 'import json,sys; print(json.dumps({"agentName": sys.argv[1]}))' "$AGENT") || return $?
    curl "${CURL_OPT[@]}" "$@" -H 'Content-Type: application/json' -d "$body" "$URL/api/auth/login/basic"
}

get()
{
    local token="$1"
    shift
    local headers=()
    if [[ -n "$token" ]]; then
        headers=(-H "Authorization: Bearer $token")
    fi
    curl "${CURL_OPT[@]}" "$@" "${headers[@]}" "$URL/api/exportKey/by/name/$POLICY"
}

get_token()
{
    python3 -c 'import json,sys
data = json.load(sys.stdin)
token = data.get("value")
if data.get("success") is not True or not isinstance(token, str) or not token:
    sys.exit("Invalid login response")
print(token)'
}

show_response()
{
    local response status
    response=$("$@" -w $'\n%{http_code}') || return $?
    status=${response##*$'\n'}
    printf '[KMSSIM] HTTP %s\n%s\n' "$status" "${response%$'\n'*}"
    [[ "$status" == 2?? ]]
}

case "${1:-help}" in
    post)
        show_response post
        ;;
    get)
        TOKEN=$(get_token < "$script_dir/login_response.json") || exit $?
        show_response get "$TOKEN"
        ;;
    no-token)
        show_response get ""
        ;;
    bad-token)
        show_response get "INVALID_SIM_TOKEN"
        ;;
    all)
        RESP=$(post -w $'\n%{http_code}') || exit $?
        STATUS=${RESP##*$'\n'}
        BODY=${RESP%$'\n'*}
        printf '[KMSSIM] Login HTTP %s\n' "$STATUS"
        if [[ "$STATUS" != 2?? ]]; then
            printf '%s\n' "$BODY"
            exit 1
        fi
        TOKEN=$(get_token <<< "$BODY") || exit $?
        show_response get "$TOKEN"
        ;;
    help)
        printf 'Usage: %s [post|get|no-token|bad-token|all|help] [policy]\n' "$0"
        ;;
    *)
        printf 'Usage: %s [post|get|no-token|bad-token|all|help] [policy]\n' "$0" >&2
        exit 1
        ;;
esac
