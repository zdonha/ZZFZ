#ifndef LGUPLUS_KMS_CLIENT_H
#define LGUPLUS_KMS_CLIENT_H

#include <stdbool.h>

/* 암복호화 결과를 담는 구조체 */
typedef struct {
    char* data;     /* 성공 시 동적 할당된 문자열, 실패 시 NULL */
    bool success;   /* 수행 성공 여부 */
} LguplusKmsResult;

/* 모듈 라이프사이클 관리 */
void lguplus_kms_init(void);
void lguplus_kms_cleanup(void);

/* 암복호화 핵심 API */
/* policy: 설정파일의 별칭 혹은 실제 정책명, data: 평문 */
LguplusKmsResult lguplus_kms_encrypt(const char* policy, const char* data);

/* policy: 설정파일의 별칭 혹은 실제 정책명, b64_data: Base64 암호문 */
LguplusKmsResult lguplus_kms_decrypt(const char* policy, const char* b64_data);

#endif

