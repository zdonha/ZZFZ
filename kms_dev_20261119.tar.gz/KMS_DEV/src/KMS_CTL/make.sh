#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
gcc -std=c99 -Wall -Wextra -Wpedantic -O2 -I../../include \
    main.c kmsctl_test.c kmsctl_shm.c kmsctl_cache.c -L../../lib -L../KMS_TEST \
    -Wl,-rpath,'$ORIGIN/../KMS_TEST' -lkms -llguplus_kms -lcrypto -o kmsctl
