/* Test-only SDK stand-in. Never link into the production kmsctl. */
#define _POSIX_C_SOURCE 200809L
#include "lguplus_kms_client.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void record(const char *event)
{
    FILE *fp;

    fp = fopen("sdk.calls", "a");
    if (fp) {
        fprintf(fp, "%s\n", event);
        fclose(fp);
    }
}

void lguplus_kms_init(void)
{
    record("init");
}

void lguplus_kms_cleanup(void)
{
    record("cleanup");
}

LguplusKmsResult lguplus_kms_encrypt(const char *policy, const char *data)
{
    LguplusKmsResult result = {0};
    size_t size;

    record("enc");
    if (strcmp(policy, "FAIL") == 0) {
        return result;
    }
    size = strlen(policy) + strlen(data) + 7;
    result.data = malloc(size);
    if (result.data) {
        snprintf(result.data, size, "ENC[%s]:%s", policy, data);
        result.success = true;
    }
    return result;
}

LguplusKmsResult lguplus_kms_decrypt(const char *policy, const char *data)
{
    LguplusKmsResult result = {0};
    char prefix[128];
    int n;

    record("dec");
    n = snprintf(prefix, sizeof(prefix), "ENC[%s]:", policy);
    if (n < 0 || (size_t)n >= sizeof(prefix) || strncmp(data, prefix, (size_t)n) != 0) {
        return result;
    }
    result.data = strdup(data + n);
    result.success = result.data != NULL;
    return result;
}
