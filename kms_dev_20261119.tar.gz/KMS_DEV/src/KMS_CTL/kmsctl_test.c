#include "kmsctl.h"
#include "kmslib.h"
#include "lguplus_kms_client.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int kmsctl_test(const char *operation, const char *policy, const char *data)
{
    LguplusKmsResult result;
    int ok;

    if (!operation || !policy || !*policy || !data ||
        (strcmp(operation, "enc") != 0 && strcmp(operation, "dec") != 0)) {
        return 0;
    }
    /* SDK only: do not initialize or modify local keys, cache, or SHM. */
    lguplus_kms_init();
    if (strcmp(operation, "enc") == 0) {
        result = lguplus_kms_encrypt(policy, data);
    } else {
        result = lguplus_kms_decrypt(policy, data);
    }
    ok = result.success && result.data != NULL;
    if (ok) {
        ok = printf("%s\n", result.data) >= 0 && fflush(stdout) == 0;
    } else {
        fprintf(stderr, "  KMS %s failed.\n", operation);
    }
    if (result.data) {
        kmslib_clear_buffer(result.data, strlen(result.data));
        free(result.data);
    }
    lguplus_kms_cleanup();
    return ok;
}
