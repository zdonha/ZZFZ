#define _POSIX_C_SOURCE 200809L
#include "kmsctl.h"
#include "kmslib.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int kmsctl_set_shm_key(const char *value)
{
    char *end;
    long key;

    if (!value) {
        value = getenv("KMS_SHM_KEY");
    }
    if (!value) {
        return 1; /* Library default, currently 0x1111. */
    }
    errno = 0;
    key = strtol(value, &end, 0);
    if (errno != 0 || end == value || *end != '\0' || !kmslib_set_shm_key(key)) {
        fprintf(stderr, "  Invalid SHM key: %s\n", value);
        return 0;
    }
    return 1;
}

int kmsctl_load_local(void)
{
    if (printf("  기존 SHM이 있으면 삭제한 뒤, 로컬 캐시로 새 SHM을 생성합니다 (KMS 미사용).\n") < 0 ||
        !kmsctl_confirm()) {
        return 0;
    }
    if (!kmslib_restore_local_cache()) {
        fprintf(stderr, "  Local cache to SHM failed: %s\n", KMS_CACHE_FILE_PATH);
        return 0;
    }
    return kmsctl_shm_status();
}

static int format_shm_time(time_t value, char *text, size_t size)
{
    struct tm local_time;

    if (value <= 0) {
        return snprintf(text, size, "-") == 1;
    }
    return localtime_r(&value, &local_time) != NULL &&
           strftime(text, size, "%Y-%m-%d %H:%M:%S", &local_time) != 0;
}

int kmsctl_shm_status(void)
{
    KMS_SHM_STATUS status;
    char updated[32] = "-";
    const char *separator = "---------------------------------------------------------------";
    int i;
    int ok;

    if (!kmslib_get_shm_status(&status)) {
        fprintf(stderr, "  Cannot read SHM status.\n");
        return 0;
    }
    if (!status.exists) {
        return printf("  SHM key=0x%lx : SHM이 없습니다.\n", (unsigned long)status.key) >= 0 &&
               fflush(stdout) == 0;
    }
    if (!format_shm_time(status.update_time, updated, sizeof(updated))) {
        fprintf(stderr, "  Cannot format SHM update time.\n");
        return 0;
    }
    ok = printf("  SHM key=0x%lx attached=%lu size=%zu updated=%s\n",
                  (unsigned long)status.key, status.attachments, status.size,
                  updated) >= 0;
    if (ok && status.ready) {
        ok = printf("  %s\n      %-15s %-12s %-10s %-11s %s\n  %s\n",
                    separator, "CRED_NAME", "USER", "POLICY", "PWD_NEW", "PWD_OLD", separator) >= 0;
        for (i = 0; ok && i < status.credential_count; i++) {
            ok = printf("  [%d] %-15s %-12s %-10s %-11s %s\n",
                        i + 1, status.credential[i].section, status.credential[i].user,
                        status.credential[i].policy[0] ? status.credential[i].policy : "-",
                        status.credential[i].has_new ? "****" : "-",
                        status.credential[i].has_old ? "****" : "-") >= 0;
        }
        if (ok) {
            ok = printf("  %s\n", separator) >= 0;
        }
    } else if (ok) {
        ok = printf("  SHM 데이터가 초기화되지 않았거나 형식이 맞지 않습니다.\n") >= 0;
    }
    return fflush(stdout) == 0 && ok;
}
