#ifndef KMSCTL_H
#define KMSCTL_H

int kmsctl_test(const char *operation, const char *policy, const char *data);
int kmsctl_set_shm_key(const char *value);
int kmsctl_load_local(void);
int kmsctl_shm_status(void);
int kmsctl_confirm(void);
int kmsctl_cache_delete(char *section);

#endif
