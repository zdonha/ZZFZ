"""Linux: python3 test_cache.py (requires gcc/cc and OpenSSL development files)."""
import ctypes as C
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import os
import random
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


class Credential(C.Structure):
    _fields_ = [("section", C.c_char * 64), ("id", C.c_char * 64),
                ("pwd", C.c_char * 4097)]


class ShmCredential(C.Structure):
    _fields_ = [("section", C.c_char * 32), ("policy", C.c_char * 64),
                ("user", C.c_char * 64), ("new_pwd_enc", C.c_char * 512),
                ("old_pwd_enc", C.c_char * 512), ("new_pwd", C.c_char * 512),
                ("old_pwd", C.c_char * 512), ("has_new", C.c_int), ("has_old", C.c_int)]


class ShmCredentials(C.Structure):
    _fields_ = [("reserved", C.c_uint32 * 3), ("kms_link_time", C.c_long),
                ("update_time", C.c_long), ("expire_time", C.c_long),
                ("credential_count", C.c_int), ("credential", ShmCredential * 16)]


class CacheTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = shutil.which("gcc") or shutil.which("cc")
        if os.name != "posix" or compiler is None:
            raise unittest.SkipTest("Linux/POSIX C compiler required")
        cls.build = tempfile.TemporaryDirectory()
        source = Path(__file__).resolve().parent
        shared = Path(cls.build.name) / "cache.so"
        cls.executable = Path(cls.build.name) / "kmsctl"
        flags = [compiler, "-std=c99", "-Wall", "-Wextra", "-Wpedantic", "-Werror", "-O2"]
        library_source = source.parent.parent / "libsrc" / "kmslib"
        if not (library_source / "kmslib_cache.c").exists():
            library_source = source.parent / "kmslib"
        flags += ["-I", str(library_source)]
        sdk_include = library_source.parent.parent / "include"
        if not sdk_include.exists():
            sdk_include = library_source.parent / "include"
        flags += ["-I", str(sdk_include)]
        common = [str(library_source / "kmslib_cache.c")]
        subprocess.run(flags + ["-shared", "-fPIC"] + common +
                       ["-o", str(shared), "-lcrypto"], check=True)
        archive = Path(cls.build.name) / "libkms.a"
        objects = []
        for name in ("kmslib_cache", "kms_shm", "kmslib"):
            obj = Path(cls.build.name) / (name + ".o")
            subprocess.run(flags + ["-c", str(library_source / (name + ".c")),
                                   "-o", str(obj)], check=True)
            objects.append(str(obj))
        subprocess.run(["ar", "rcs", str(archive)] + objects, check=True)
        fake_sdk = Path(cls.build.name) / "liblguplus_kms.so"
        subprocess.run(flags + ["-shared", "-fPIC", str(source / "test_sdk.c"),
                               "-o", str(fake_sdk)], check=True)
        subprocess.run(flags + [str(source / name) for name in
                               ("main.c", "kmsctl_test.c", "kmsctl_shm.c", "kmsctl_cache.c")] +
                       ["-L", cls.build.name, "-Wl,-rpath," + cls.build.name,
                        "-lkms", "-llguplus_kms", "-o", str(cls.executable), "-lcrypto"], check=True)
        ipc_library = Path(cls.build.name) / "ipc.so"
        subprocess.run(flags + ["-shared", "-fPIC"] +
                       [str(library_source / name) for name in
                        ("kmslib_cache.c", "kms_shm.c", "kmslib.c")] +
                       [str(source / "test_sdk.c"), "-o", str(ipc_library), "-lcrypto"], check=True)
        cls.shm_lib = C.CDLL(str(ipc_library))
        cls.shm_lib.kmslib_set_shm_key.argtypes = [C.c_long]
        cls.shm_lib.kmslib_load_credential.argtypes = [C.POINTER(C.c_void_p)]
        cls.shm_lib.kmslib_detach_credential.argtypes = [C.POINTER(C.c_void_p)]
        cls.shm_lib.kmslib_get_account.argtypes = [C.c_void_p, C.c_char_p, C.c_int,
                                                 C.c_char_p, C.c_size_t,
                                                 C.c_char_p, C.c_size_t]
        cls.shm_lib.kmslib_get_account_all.argtypes = [C.c_void_p, C.c_char_p,
                                                      C.c_char_p, C.c_size_t,
                                                      C.c_char_p, C.c_size_t,
                                                      C.c_char_p, C.c_size_t]
        cls.shm_lib.kmslib_get_password.argtypes = [C.POINTER(ShmCredential), C.c_int,
                                                   C.c_char_p, C.c_size_t]
        cls.lib = C.CDLL(str(shared))
        cls.lib.kms_cache_create_key.argtypes = [C.c_char_p]
        cls.lib.kms_cache_save.argtypes = [C.c_char_p] * 3
        cls.lib.kms_cache_delete.argtypes = [C.c_char_p]
        cls.lib.kms_cache_read.argtypes = [C.c_char_p, C.c_char_p,
                                          C.POINTER(Credential), C.c_size_t,
                                          C.POINTER(C.c_size_t)]

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.previous = Path.cwd()
        os.chdir(self.directory.name)
        self.key = Path("kms_cache.key")
        self.cache = Path("kms_credential.cache")
        self.assertEqual(self.lib.kms_cache_create_key(bytes(self.key)), 1)

    def tearDown(self):
        os.chdir(self.previous)
        self.directory.cleanup()

    def save(self, section=b"DB_MAIN", user=b"db_user", password=b"test_secret_123"):
        return self.lib.kms_cache_save(section, user, password)

    def read(self, success=True):
        items = (Credential * 10)()
        C.memset(items, 0x58, C.sizeof(items))
        count = C.c_size_t(99)
        result = self.lib.kms_cache_read(bytes(self.key), bytes(self.cache),
                                         items, 10, C.byref(count))
        self.assertEqual(result, int(success))
        if not success:
            self.assertEqual(count.value, 0)
            self.assertEqual(bytes(items), bytes(C.sizeof(items)))
        return items, count.value

    def test_roundtrip_format_and_output(self):
        self.assertEqual(self.save(), 1)
        raw = self.cache.read_bytes()
        self.assertEqual(raw[:4], b"KMC2")
        self.assertIn(b"DB_MAIN", raw)
        self.assertIn(b"db_user", raw)
        self.assertNotIn(b"test_secret_123", raw)
        items, count = self.read()
        self.assertEqual(count, 1)
        self.assertEqual((items[0].section, items[0].id, items[0].pwd),
                         (b"DB_MAIN", b"db_user", b"test_secret_123"))
        self.assertEqual(self.cache.stat().st_mode & 0o777, 0o600)
        output = subprocess.run([str(self.executable), "cache", "load"], check=True,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout
        self.assertIn(b"SECTION=DB_MAIN USER=db_user PWD=test_secret_123", output)

    def test_add_update_and_limit(self):
        for index in range(10):
            self.assertEqual(self.save(f"DB_{index}".encode()), 1)
        before = self.cache.read_bytes()
        self.assertEqual(self.save(b"EXTRA"), 0)
        self.assertEqual(self.cache.read_bytes(), before)
        self.assertEqual(self.save(b"DB_0", b"new_user", b"new_pwd"), 1)
        items, count = self.read()
        self.assertEqual(count, 10)
        self.assertEqual((items[0].id, items[0].pwd), (b"new_user", b"new_pwd"))

    def test_tampering_truncation_and_old_format(self):
        self.assertEqual(self.save(), 1)
        original = self.cache.read_bytes()
        # Magic, nonce, tag, SECTION, USER, ciphertext.
        for offset in (0, 4, 16, 32, 96, 160):
            with self.subTest(offset=offset):
                damaged = bytearray(original)
                damaged[offset] ^= 1
                self.cache.write_bytes(damaged)
                self.read(False)
                self.assertEqual(self.save(), 0)
                self.assertEqual(self.cache.read_bytes(), damaged)
        for damaged in (b"", original[:-1], original + b"x", b"KMC1" + original[4:]):
            self.cache.write_bytes(damaged)
            self.read(False)
            self.assertEqual(self.save(), 0)
            self.assertEqual(self.cache.read_bytes(), damaged)

    def test_wrong_key_and_missing_cache(self):
        self.read(False)
        self.assertEqual(self.save(), 1)
        before = self.cache.read_bytes()
        self.key.write_bytes(os.urandom(32))
        self.read(False)
        self.assertEqual(self.save(), 0)
        self.assertEqual(self.cache.read_bytes(), before)

    def test_field_boundaries_and_nonce(self):
        self.assertEqual(self.save(b"S" * 63, b"U" * 63, b"P" * 4096), 1)
        items, count = self.read()
        self.assertEqual(count, 1)
        self.assertEqual(items[0].pwd, b"P" * 4096)
        before = self.cache.read_bytes()
        for values in ((b"S" * 64, b"u", b"p"), (b"s", b"U" * 64, b"p"),
                       (b"s", b"u", b"P" * 4097), (b"", b"u", b"p"),
                       (b"s", None, b"p"), (b"s", b"u", b"")):
            self.assertEqual(self.save(*values), 0)
            self.assertEqual(self.cache.read_bytes(), before)
        self.assertEqual(self.save(b"S" * 63, b"U" * 63, b"P" * 4096), 1)
        self.assertNotEqual(self.cache.read_bytes()[4:16], before[4:16])

    def test_cli_init_add_delete_empty_and_readd(self):
        def run(*args, expected=0):
            group = "key" if args[0] == "init" else "cache"
            result = subprocess.run([str(self.executable), group, *args],
                                    input=b"Y\n", stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.assertEqual(result.returncode, expected, result.stderr)
            return result.stdout

        old_key = self.key.read_bytes()
        run("init", expected=1)
        self.assertEqual(self.key.read_bytes(), old_key)
        run("add", "A", "user_a", "pwd_a")
        run("add", "B", "user_b", "pwd_b")
        run("add", "C", "user_c", "pwd_c")
        run("del", "B")
        items, count = self.read()
        self.assertEqual([items[i].section for i in range(count)], [b"A", b"C"])
        before = self.cache.read_bytes()
        run("del", "MISSING", expected=1)
        self.assertEqual(self.cache.read_bytes(), before)
        run("del", "A")
        run("del", "C")
        self.assertEqual(self.read()[1], 0)
        self.assertIn(b"Loaded 0", run("load"))
        run("add", "NEW", "new_user", "new_pwd")
        self.assertEqual(self.read()[1], 1)
        run("add", expected=1)

    def test_init_once(self):
        self.key.unlink()
        self.assertEqual(self.lib.kms_cache_init(), 1)
        key = self.key.read_bytes()
        self.assertEqual(len(key), 32)
        self.assertEqual(self.key.stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.lib.kms_cache_init(), 0)
        self.assertEqual(self.key.read_bytes(), key)

    def test_legacy_cache_read_and_upgrade(self):
        legacy = os.environ.get("KMS_LEGACY_EXECUTABLE")
        if not legacy:
            self.skipTest("Set KMS_LEGACY_EXECUTABLE to the original KMC1 binary")
        subprocess.run([legacy, "save-demo", str(self.key), str(self.cache)], check=True)
        self.assertEqual(self.cache.read_bytes()[:4], b"KMC1")
        items, count = self.read()
        self.assertEqual(count, 1)
        self.assertEqual((items[0].section, items[0].id, items[0].pwd),
                         (b"DB_MAIN", b"sample_user", b"sample_password"))
        original = self.cache.read_bytes()
        self.assertIn("PWD=********", self.command("cache", "view"))
        self.assertEqual(self.cache.read_bytes(), original)
        self.assertEqual(self.save(b"EXTRA"), 1)
        self.assertEqual(self.cache.read_bytes()[:4], b"KMC2")
        items, count = self.read()
        self.assertEqual(count, 2)
        self.assertEqual(items[0].pwd, b"sample_password")

    def test_concurrent_process_and_thread_add(self):
        processes = [subprocess.Popen([str(self.executable), "cache", "add", "DB_" + str(i),
                                      "test_user", "test_pwd"],
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                     for i in range(8)]
        for process in processes:
            output, error = process.communicate(timeout=15)
            self.assertEqual(process.returncode, 0, error)
        items, count = self.read()
        self.assertEqual({items[i].section for i in range(count)},
                         {("DB_" + str(i)).encode() for i in range(8)})
        for i in range(8):
            self.assertEqual(self.lib.kms_cache_delete(("DB_" + str(i)).encode()), 1)
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda i: self.save(("THREAD_" + str(i)).encode()),
                                    range(8)))
        self.assertEqual(results, [1] * 8)
        items, count = self.read()
        self.assertEqual({items[i].section for i in range(count)},
                         {("THREAD_" + str(i)).encode() for i in range(8)})
        lock_file = Path(".kms_credential.cache.lock")
        self.assertTrue(lock_file.is_file())
        self.assertEqual(lock_file.stat().st_mode & 0o777, 0o600)
        self.assertFalse(Path("kms_credential.cache.lock").exists())

    def command(self, *args, expected=0, answer=b"Y\n"):
        result = subprocess.run([str(self.executable), *args],
                                input=answer, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=15)
        self.assertEqual(result.returncode, expected, result.stderr)
        index = 2 if args and args[0] == "--shm-key" else 0
        sdk_test = len(args) > index and args[index] == "test"
        formatted = result.stderr if sdk_test else result.stdout + result.stderr
        for line in formatted.splitlines():
            self.assertTrue(line.startswith(b"  "), line)
        return result.stdout.decode()

    def test_cache_view_masked_and_readonly(self):
        self.assertEqual(self.save(password=b"sensitive_password_1"), 1)
        self.assertEqual(self.save(b"FTP_MAIN", b"ftp_user", b"sensitive_password_2"), 1)
        before = self.cache.read_bytes()
        before_key = self.key.read_bytes()
        output = self.command("cache", "view")
        self.assertEqual(output, "  SECTION=DB_MAIN USER=db_user PWD=********\n"
                                 "  SECTION=FTP_MAIN USER=ftp_user PWD=********\n"
                                 "  Total 2 credential(s).\n")
        self.assertNotIn("sensitive_password", output)
        self.assertEqual(self.cache.read_bytes(), before)
        self.assertEqual(self.key.read_bytes(), before_key)
        self.assertFalse(Path("sdk.calls").exists())

    def test_cache_view_invalid_empty_and_wrong_key(self):
        self.assertEqual(self.command("cache", "view", expected=1), "")
        self.assertEqual(self.save(password=b"secret_not_printed"), 1)
        original = self.cache.read_bytes()
        self.cache.write_bytes(original[:-1])
        self.assertEqual(self.command("cache", "view", expected=1), "")
        self.cache.write_bytes(original)
        key = self.key.read_bytes()
        self.key.write_bytes(os.urandom(32))
        self.assertEqual(self.command("cache", "view", expected=1), "")
        self.key.write_bytes(key)
        self.command("cache", "del", "DB_MAIN")
        self.assertEqual(self.command("cache", "view"), "  Total 0 credential(s).\n")

    def own_ipc(self):
        libc = C.CDLL(None, use_errno=True)
        libc.shmget.argtypes = [C.c_int, C.c_size_t, C.c_int]
        libc.shmat.argtypes = [C.c_int, C.c_void_p, C.c_int]
        libc.shmat.restype = C.c_void_p
        libc.shmdt.argtypes = [C.c_void_p]
        libc.shmctl.argtypes = [C.c_int, C.c_int, C.c_void_p]
        for _ in range(100):
            key = random.SystemRandom().randint(0x40000000, 0x7fffffff)
            if libc.shmget(key, 1, 0o600) >= 0:
                continue
            semaphore = libc.semget(key, 1, 0o1000 | 0o2000 | 0o600)
            if semaphore >= 0:
                break
        else:
            self.fail("Cannot reserve isolated IPC key")

        def cleanup():
            shmid = libc.shmget(key, 1, 0o600)
            if shmid >= 0:
                libc.shmctl(shmid, 0, None)
            libc.semctl(semaphore, 0, 0)
        self.addCleanup(cleanup)
        return libc, key

    def test_kms_test_commands_do_not_change_cache_or_shm(self):
        self.assertEqual(self.save(), 1)
        before_key = self.key.read_bytes()
        before_cache = self.cache.read_bytes()
        libc, key = self.own_ipc()
        encrypted = self.command("--shm-key", str(key), "test", "enc", "DEV_01", "hello")
        self.assertEqual(encrypted, "ENC[DEV_01]:hello\n")
        self.assertEqual(self.command("test", "dec", "DEV_01", encrypted.rstrip("\n")), "hello\n")
        self.command("test", "enc", "FAIL", "hello", expected=1)
        self.command("test", "dec", "DEV_01", "bad", expected=1)
        self.assertEqual(self.key.read_bytes(), before_key)
        self.assertEqual(self.cache.read_bytes(), before_cache)
        self.assertLess(libc.shmget(key, 1, 0o600), 0)
        self.assertIn("enc", Path("sdk.calls").read_text())

    def test_local_shm_restore_status_and_busy_rejection(self):
        libc, key = self.own_ipc()
        args = ("--shm-key", str(key), "shm")
        self.assertIn("SHM이 없습니다.", self.command(*args, "status"))
        self.assertLess(libc.shmget(key, 1, 0o600), 0)
        self.assertEqual(self.save(), 1)
        before_key = self.key.read_bytes()
        before_cache = self.cache.read_bytes()
        result = self.command(*args, "load-local")
        self.assertIn("PWD_NEW", result)
        self.assertRegex(result, r"\[1\]\s+DB_MAIN\s+db_user\s+-\s+\*{4}\s+-")
        summary = [line for line in result.splitlines() if " updated=" in line][-1]
        datetime.strptime(summary.split(" updated=", 1)[1], "%Y-%m-%d %H:%M:%S")
        shmid = libc.shmget(key, 1, 0o600)
        address = libc.shmat(shmid, None, 0)
        self.assertNotEqual(address, C.c_void_p(-1).value)
        try:
            self.command(*args, "load-local", expected=1)
            self.assertEqual(libc.shmget(key, 1, 0o600), shmid)
            self.assertIn("attached=1", self.command(*args, "status"))
        finally:
            libc.shmdt(address)
        # BLOCK path must reuse ready SHM without initiating KMS.
        self.assertEqual(self.shm_lib.kmslib_set_shm_key(key), 1)
        handle = C.c_void_p()
        self.assertEqual(self.shm_lib.kmslib_load_credential(C.byref(handle)), 1)
        try:
            user = C.create_string_buffer(64)
            password = C.create_string_buffer(512)
            self.assertEqual(self.shm_lib.kmslib_get_account(handle, b"DB_MAIN", 0,
                                                            user, len(user), password, len(password)), 1)
            self.assertEqual((user.value, password.value), (b"db_user", b"test_secret_123"))
        finally:
            self.assertEqual(self.shm_lib.kmslib_detach_credential(C.byref(handle)), 1)
        self.command(*args, "load-local")
        self.assertNotEqual(libc.shmget(key, 1, 0o600), shmid)
        self.assertEqual(self.key.read_bytes(), before_key)
        self.assertEqual(self.cache.read_bytes(), before_cache)
        self.assertFalse(Path("sdk.calls").exists())

    def test_bad_cache_or_shm_field_size_preserves_existing_shm(self):
        libc, key = self.own_ipc()
        args = ("--shm-key", str(key), "shm")
        self.assertEqual(self.save(), 1)
        self.command(*args, "load-local")
        shmid = libc.shmget(key, 1, 0o600)
        original = self.cache.read_bytes()
        self.cache.write_bytes(original[:-1])
        self.command(*args, "load-local", expected=1)
        self.assertEqual(libc.shmget(key, 1, 0o600), shmid)
        self.cache.write_bytes(original)
        self.assertEqual(self.save(b"SECTION_" + b"X" * 32), 1)
        self.command(*args, "load-local", expected=1)
        self.assertEqual(libc.shmget(key, 1, 0o600), shmid)
        self.assertEqual(self.lib.kms_cache_delete(b"SECTION_" + b"X" * 32), 1)
        self.assertEqual(self.save(password=b"P" * 512), 1)
        self.command(*args, "load-local", expected=1)
        self.assertEqual(libc.shmget(key, 1, 0o600), shmid)

    def test_invalid_command_and_shm_key(self):
        for args in ((), ("unknown",), ("key",), ("cache", "add"), ("shm", "clear"),
                     ("test", "enc", "POLICY"), ("test", "bad", "P", "D"),
                     ("--shm-key", "0", "shm", "status"),
                     ("--shm-key", "invalid", "shm", "status")):
            self.command(*args, expected=1)

    def test_shm_status_shows_metadata_without_any_passwords(self):
        libc, key = self.own_ipc()
        args = ("--shm-key", str(key), "shm")
        self.assertEqual(self.save(password=b"plain_new_secret"), 1)
        self.command(*args, "load-local")
        shmid = libc.shmget(key, 1, 0o600)
        address = libc.shmat(shmid, None, 0)
        self.assertNotEqual(address, C.c_void_p(-1).value)
        try:
            shm = ShmCredentials.from_address(address)
            shm.kms_link_time = 1795083642
            shm.expire_time = 1795170042
            shm.reserved[:] = (10, 20, 30)
            shm.credential[0].policy = b"DEV_01"
            shm.credential[0].old_pwd = b"plain_old_secret"
            shm.credential[0].new_pwd_enc = b"encrypted_new_secret"
            shm.credential[0].old_pwd_enc = b"encrypted_old_secret"
            shm.credential[0].has_old = 1
            before = C.string_at(address, C.sizeof(ShmCredentials))
            output = self.command(*args, "status")
            self.assertRegex(output, r"\[1\]\s+DB_MAIN\s+db_user\s+DEV_01\s+\*{4}\s+\*{4}")
            self.assertIn("PWD_NEW", output)
            self.assertIn("PWD_OLD", output)
            for hidden in (" id=", "state=", "count=", "KMS_LINK_TIME=", "EXPIRE_TIME=", "RESERVED=", "HAS_NEW="):
                self.assertNotIn(hidden, output)
            for secret in ("plain_new_secret", "plain_old_secret", "encrypted_new_secret", "encrypted_old_secret"):
                self.assertNotIn(secret, output)
            self.assertTrue(all(line.strip() for line in output.splitlines()))
            self.assertEqual(C.string_at(address, C.sizeof(ShmCredentials)), before)
            self.assertFalse(Path("sdk.calls").exists())
        finally:
            libc.shmdt(address)

    def test_usage_format(self):
        result = subprocess.run([str(self.executable)], stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=15)
        self.assertEqual(result.returncode, 1)
        program = str(self.executable)
        expected = ["  Usage: " + program + " COMMAND"]
        expected += ["  " + program + " " + command.split(" # ", 1)[0].ljust(32) +
                     " # " + command.split(" # ", 1)[1] for command in
                     ("test enc POLICY PWD # KMS 암호화 테스트",
                      "test dec POLICY ENC_PWD # KMS 복호화 테스트",
                      "key init # 로컬 키 생성 (기존 키 유지)",
                      "cache add CRED_NAME USER PASSWD # 계정 추가/변경, 비밀번호 암호화 저장",
                      "cache del CRED_NAME # CRED_NAME 계정 삭제",
                      "cache load # 메모리 로딩 및 비밀번호 평문 출력",
                      "cache view # 계정 조회, 비밀번호 마스킹",
                      "shm load-local # 로컬 캐시로 SHM 복구 (KMS 미사용)",
                      "shm status # SHM 상태 조회")]
        self.assertEqual(result.stderr.decode().splitlines(), expected)
        self.assertNotIn(b"--shm-key", result.stderr)

    def test_password_lookup_validation_and_old_fallback(self):
        cred = ShmCredential()
        cred.new_pwd = b"new_pwd"
        cred.old_pwd = b"old_pwd"
        cred.has_new = cred.has_old = 1
        output = C.create_string_buffer(32)
        getter = self.shm_lib.kmslib_get_password
        self.assertEqual(getter(C.byref(cred), 0, output, len(output)), 1)
        self.assertEqual(output.value, b"new_pwd")
        self.assertEqual(getter(C.byref(cred), 1, output, len(output)), 1)
        self.assertEqual(output.value, b"old_pwd")
        cred.has_new = 0
        self.assertEqual(getter(C.byref(cred), 0, output, len(output)), 1)
        self.assertEqual(output.value, b"old_pwd")
        cred.has_new = 1
        cred.new_pwd = b""
        self.assertEqual(getter(C.byref(cred), 0, output, len(output)), 1)
        self.assertEqual(output.value, b"old_pwd")
        cred.new_pwd = cred.old_pwd
        self.assertEqual(getter(C.byref(cred), 1, output, len(output)), 1)
        for entry, attempt in ((None, 0), (C.byref(cred), 2)):
            C.memset(output, 88, len(output))
            self.assertEqual(getter(entry, attempt, output, len(output)), 0)
            self.assertEqual(output.raw, bytes(len(output)))
        self.assertEqual(getter(C.byref(cred), 0, None, 0), 0)
        small = C.create_string_buffer(2)
        self.assertEqual(getter(C.byref(cred), 0, small, len(small)), 0)
        self.assertEqual(small.raw, bytes(len(small)))

    def test_account_all_user_old_buffers_and_invalid_arguments(self):
        libc, key = self.own_ipc()
        self.assertEqual(self.save(password=b"new_pwd"), 1)
        self.command("--shm-key", str(key), "shm", "load-local")
        self.assertEqual(self.shm_lib.kmslib_set_shm_key(key), 1)
        address = libc.shmat(libc.shmget(key, 1, 0o600), None, 0)
        self.assertNotEqual(address, C.c_void_p(-1).value)
        try:
            shm = ShmCredentials.from_address(address)
            shm.credential[0].old_pwd = b"old_pwd"
            shm.credential[0].has_old = 1
            getter = self.shm_lib.kmslib_get_account_all
            user = C.create_string_buffer(64)
            password = C.create_string_buffer(512)
            old = C.create_string_buffer(512)
            self.assertEqual(getter(address, b"DB_MAIN", user, len(user),
                                    password, len(password), old, len(old)), 1)
            self.assertEqual((user.value, password.value, old.value),
                             (b"db_user", b"new_pwd", b"old_pwd"))
            self.assertEqual(getter(address, b"DB_MAIN", user, len(user),
                                    password, len(password), None, 0), 1)
            for handle, section, pwd_size, old_size in (
                    (None, b"DB_MAIN", len(password), len(old)),
                    (address, b"MISSING", len(password), len(old)),
                    (address, b"DB_MAIN", 2, len(old)),
                    (address, b"DB_MAIN", len(password), 2)):
                user.value = b"stale_user"
                C.memset(password, 88, len(password))
                C.memset(old, 88, len(old))
                self.assertEqual(getter(handle, section, user, len(user),
                                        password, pwd_size, old, old_size), 0)
                self.assertEqual(user.value, b"")
                self.assertEqual(password.raw[:pwd_size], bytes(pwd_size))
                self.assertEqual(old.raw[:old_size], bytes(old_size))
            shm.credential[0].has_new = 0
            self.assertEqual(getter(address, b"DB_MAIN", user, len(user),
                                    password, len(password), old, len(old)), 1)
            self.assertEqual((user.value, password.value, old.value),
                             (b"db_user", b"old_pwd", b"old_pwd"))
            strict = self.shm_lib.kmslib_get_account
            self.assertEqual(strict(address, b"DB_MAIN", 0, user, len(user), password, len(password)), 0)
            self.assertEqual(strict(address, b"DB_MAIN", 1, user, len(user), password, len(password)), 1)
            self.assertEqual((user.value, password.value), (b"db_user", b"old_pwd"))
            shm.credential[0].has_old = 0
            self.assertEqual(getter(address, b"DB_MAIN", user, len(user),
                                    password, len(password), old, len(old)), 0)
            self.assertEqual((user.value, password.value, old.value), (b"", b"", b""))
            self.assertFalse(Path("sdk.calls").exists())
        finally:
            libc.shmdt(address)

    def test_delete_confirmation_and_changed_account(self):
        self.assertEqual(self.save(), 1)
        before = self.cache.read_bytes()
        for answer in (b"N\n", b"n\n", b"", b"invalid\nN\n", b"Y" * 100 + b"\nN\n"):
            output = self.command("cache", "del", "DB_MAIN", expected=1, answer=answer)
            self.assertIn("CRED_NAME=DB_MAIN USER=db_user PWD=********", output)
            self.assertIn("진행하시겠습니까? (y/n):", output)
            self.assertNotIn("test_secret_123", output)
            self.assertEqual(self.cache.read_bytes(), before)
        expected = Credential(b"DB_MAIN", b"db_user", b"test_secret_123")
        self.assertEqual(self.save(password=b"changed_pwd"), 1)
        current = self.cache.read_bytes()
        self.lib.kms_cache_delete_if_unchanged.argtypes = [C.POINTER(Credential)]
        self.assertEqual(self.lib.kms_cache_delete_if_unchanged(C.byref(expected)), 0)
        self.assertEqual(self.cache.read_bytes(), current)
        self.command("cache", "del", "DB_MAIN", answer=b"y\n")
        self.assertEqual(self.read()[1], 0)

    def test_shm_restore_confirmation_and_delete_notice(self):
        libc, key = self.own_ipc()
        args = ("--shm-key", str(key), "shm")
        self.assertEqual(self.save(), 1)
        output = self.command(*args, "load-local", expected=1, answer=b"N\n")
        self.assertIn("기존 SHM이 있으면 삭제", output)
        self.assertIn("진행하시겠습니까? (y/n):", output)
        self.assertLess(libc.shmget(key, 1, 0o600), 0)
        output = self.command(*args, "load-local", answer=b"Y\n")
        self.assertLess(output.index("진행하시겠습니까?"), output.index("SHM key="))
        shmid = libc.shmget(key, 1, 0o600)
        for answer in (b"N\n", b""):
            self.command(*args, "load-local", expected=1, answer=answer)
            self.assertEqual(libc.shmget(key, 1, 0o600), shmid)
        self.command(*args, "load-local", answer=b"y\n")
        self.assertNotEqual(libc.shmget(key, 1, 0o600), shmid)


if __name__ == "__main__":
    unittest.main(verbosity=2)
