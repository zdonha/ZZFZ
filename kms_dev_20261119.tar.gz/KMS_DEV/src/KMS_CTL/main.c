#include "kmsctl.h"
#include "kmslib.h"
#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
    const char *program;
    const char *shm_key;
    int offset;
    int ok;

    program = argv[0];
    offset = 1;
    shm_key = NULL;
    if (argc >= 3 && strcmp(argv[1], "--shm-key") == 0) {
        shm_key = argv[2];
        offset = 3;
    }
    argc -= offset;
    argv += offset;

    if (argc == 4 && strcmp(argv[0], "test") == 0 &&
        (strcmp(argv[1], "enc") == 0 || strcmp(argv[1], "dec") == 0)) {
        ok = kmsctl_test(argv[1], argv[2], argv[3]);
    } else if (argc == 2 && strcmp(argv[0], "key") == 0 && strcmp(argv[1], "init") == 0) {
        ok = kms_cache_init();
    } else if (argc == 5 && strcmp(argv[0], "cache") == 0 && strcmp(argv[1], "add") == 0) {
        ok = kms_cache_save(argv[2], argv[3], argv[4]);
    } else if (argc == 3 && strcmp(argv[0], "cache") == 0 && strcmp(argv[1], "del") == 0) {
        ok = kmsctl_cache_delete(argv[2]);
    } else if (argc == 2 && strcmp(argv[0], "cache") == 0 && strcmp(argv[1], "load") == 0) {
        ok = kms_cache_load();
    } else if (argc == 2 && strcmp(argv[0], "cache") == 0 && strcmp(argv[1], "view") == 0) {
        ok = kms_cache_view();
    } else if (argc == 2 && strcmp(argv[0], "shm") == 0 &&
               (strcmp(argv[1], "load-local") == 0 || strcmp(argv[1], "status") == 0)) {
        if (!kmsctl_set_shm_key(shm_key)) {
            return 1;
        }
        ok = strcmp(argv[1], "load-local") == 0 ? kmsctl_load_local() : kmsctl_shm_status();
    } else {
        goto usage;
    }
    return ok ? 0 : 1;
usage:
    fprintf(stderr, "  Usage: %s COMMAND\n"
                    "  %s test enc POLICY PWD              # KMS 암호화 테스트\n"
                    "  %s test dec POLICY ENC_PWD          # KMS 복호화 테스트\n"
                    "  %s key init                         # 로컬 키 생성 (기존 키 유지)\n"
                    "  %s cache add CRED_NAME USER PASSWD  # 계정 추가/변경, 비밀번호 암호화 저장\n"
                    "  %s cache del CRED_NAME              # CRED_NAME 계정 삭제\n"
                    "  %s cache load                       # 메모리 로딩 및 비밀번호 평문 출력\n"
                    "  %s cache view                       # 계정 조회, 비밀번호 마스킹\n"
                    "  %s shm load-local                   # 로컬 캐시로 SHM 복구 (KMS 미사용)\n"
                    "  %s shm status                       # SHM 상태 조회\n",
                    program, program, program, program, program,
                    program, program, program, program, program);
    return 1;
}
