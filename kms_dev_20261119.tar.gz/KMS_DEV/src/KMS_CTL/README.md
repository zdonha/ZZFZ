# kmsctl

KMS 연동 점검, 로컬 키/캐시 관리, 비상 SHM 복구를 하나의 실행 파일로 제공합니다.
VM 작업 디렉터리는 `/data1/donha/KMS_DEV/src/KMS_CTL`이며 실행 파일은 `kmsctl`입니다.

## 빌드

```sh
cd /data1/donha/KMS_DEV/libsrc/kmslib
make
cd ../../src/KMS_CTL
sh make.sh
```

- `main.c`: 명령 구분과 함수 호출.
- `kmsctl_test.c`: 기존 SDK를 이용한 암복호화 점검.
- `kmsctl_shm.c`: SHM 키 설정, 복구 호출, 상태 출력.
- `kmslib_cache.c`: 기존 공통 캐시 구현.
- `kms_shm.c`: SHM 상태 조회와 로컬 캐시 복구 API 추가.
- `kmslib.h`: 공통 구조체/상수/함수 선언.
- `libkms.a`, OpenSSL libcrypto, `../KMS_TEST/liblguplus_kms.so`에 링크합니다.
- SDK 경로는 실행 파일 기준 `../KMS_TEST` RPATH로 지정합니다.

## 명령

```sh
./kmsctl test enc POLICY PWD
./kmsctl test dec POLICY ENC_PWD
./kmsctl key init
./kmsctl cache add CRED_NAME USER PASSWD
./kmsctl cache del CRED_NAME
./kmsctl cache load
./kmsctl cache view
./kmsctl shm load-local
./kmsctl shm status
```

### test

- KMS 암/복호화만 수행하고 결과를 출력합니다.
- 성공 결과는 앞 공백 없이 출력합니다. 그 외 안내/오류/표 출력은 앞 공백 두 칸을 유지합니다.
- 로컬 키, 캐시, SHM을 생성/갱신하지 않습니다.
- 현재 실행 디렉터리의 `kms.properties`를 SDK가 사용합니다. 기존 테스트 설정은 새 실행 디렉터리에 복사하되, 이미 있는 설정은 덮어쓰지 않습니다.
- 기존 SDK 초기화/종료 및 반환 문자열 해제 규약을 유지합니다.

### key / cache

- `key init`: 랜덤 32바이트 로컬 키 생성. 기존 키가 있으면 변경 없이 실패.
- `cache add`: SECTION 기준 추가/갱신. SECTION/USER 평문, PASSWD는 AES-256-GCM 암호화.
- `cache del`: SECTION 삭제. 없는 SECTION은 실패. 마지막 계정 삭제 시 인증된 빈 캐시 저장.
- `cache del`은 대상 CRED_NAME/USER/마스킹 비밀번호를 표시한 뒤 Y/N 확인을 받습니다. N/입력 종료 시 변경하지 않으며, 확인 중 계정이 바뀌었다면 삭제를 거부합니다. mmib용 공통 삭제 함수는 입력 없이 동작합니다.
- `cache load`: 캐시 전체 검증/복호화 후 메모리 적재와 확인용 출력. **평문 비밀번호도 출력합니다.**
- `cache view`: 전체 검증 후 SECTION/USER 표시, 비밀번호는 길이와 무관하게 `********`로 마스킹합니다. 키/캐시/SHM은 변경하지 않습니다.
- 안내와 오류 메시지는 각 줄 앞에 공백 두 칸을 붙입니다. test enc/dec 성공 결과는 예외입니다. 외부 SDK 자체 메시지는 SDK 형식을 따릅니다.
- 파일: 현재 실행 디렉터리의 `kms_cache.key`, `kms_credential.cache`.
- 최대 10건. SECTION/USER 최대 63바이트, PASSWD 최대 4096바이트.
- SECTION/USER도 변조 검증에 포함합니다. 기존 KMC1 캐시는 읽고 다음 저장부터 KMC2 사용.
- 키/캐시/잠금 파일 생성 권한은 0600. 잠금 파일은 캐시와 같은 디렉터리의 `.kms_credential.cache.lock`이며 일반 ls에는 보이지 않습니다. 실행 중 삭제하지 마세요.
- 공통 변경 함수는 캐시 읽기부터 임시 파일 저장/교체까지 flock으로 직렬화합니다.

### shm

운영 BLOCK이 사용하는 `commlib_getShmKey(..., "KMS_SHM", ...)`의 값과 같은 키를 지정해야 합니다.
기본값은 기존 라이브러리의 `0x1111`입니다. 명시 옵션이 환경 변수보다 우선합니다.

```sh
./kmsctl --shm-key 0x1111 shm status
./kmsctl --shm-key 0x1111 shm load-local

export KMS_SHM_KEY=0x1111
./kmsctl shm status
```

- `shm status`: 키, 접속 수, 크기, 갱신 시각 및 계정별 표를 출력합니다. SHM이 없으면 생성하지 않습니다.
- `updated`는 VM의 로컬 시간대 기준 `YYYY-MM-DD HH:MM:SS`입니다. 갱신 시각이 없는 경우 `-`로 표시합니다.
- 계정 표는 CRED_NAME/USER/POLICY/PWD_NEW/PWD_OLD를 표시합니다. 비밀번호가 있으면 `****`, 없으면 `-`입니다. 평문 비밀번호와 암호문은 출력하지 않습니다.
- ID/STATE/KMS_LINK_TIME/EXPIRE_TIME/RESERVED는 표시하지 않습니다. 기존 BLOCK과 호환되도록 내부 SHM 구조는 유지합니다.
- 로컬 캐시는 정책/OLD 비밀번호를 저장하지 않으므로 로컬 복구 후 POLICY/PWD_OLD는 `-`입니다. KMS 정상 경로로 구성한 SHM에는 저장된 정책이 표시됩니다.
- `shm load-local`: KMS 호출 없이 캐시 전체 검증/복호화 → SHM 필드 길이 검증 → 기존 SHM 사용 여부 확인 → 기존 SHM 삭제 → 새 SHM 생성/적재.
- 기존 SHM 삭제 안내 → 진행하시겠습니까? (y/n) → 캐시 검증 및 SHM 복구 → 결과 표 순서로 동작합니다. Y/y만 진행하며 N/n/입력 종료는 취소합니다. 대기 중에는 캐시/SHM 잠금을 유지하지 않습니다.
- 전체 BLOCK 종료 후 실행하세요. 기존 SHM에 프로세스가 붙어 있으면 복구를 거부합니다.
- 캐시 검증이나 필드 길이 검증 실패 시 기존 SHM은 유지합니다. 기존 SHM 삭제 이후 OS 생성/접속 오류가 발생하면 재실행이 필요합니다.
- 기존 SHM 형식은 SECTION 최대 31바이트, USER 최대 63바이트, 비밀번호 최대 511바이트입니다. 캐시가 이 길이를 넘으면 복구를 거부하고 잘라서 저장하지 않습니다.
- 캐시의 단일 비밀번호를 SHM의 NEW 비밀번호로 적재합니다. OLD/POLICY/KMS 암호문은 캐시에 없으므로 빈 값입니다.
- `kms_link_time`은 0, `update_time`은 로컬 복구 시각입니다. 기존 BLOCK은 준비된 SHM을 그대로 사용합니다.
- SHM 데이터 구조와 기존 초기화/조회 API는 유지합니다. SHM 세마포어로 복구와 정상 SHM 접근을 직렬화합니다.

## mmib 연결

```c
#include "kmslib.h"

kms_cache_save(section, user, passwd);
kms_cache_delete(section);
```

반환값은 성공 1, 실패 0입니다. CLI 종료 코드는 성공 0, 실패 1입니다.
mmib/CLI는 같은 절대 경로 또는 같은 패키지 작업 디렉터리를 사용해야 합니다.
캐시 함수 사용 시 `-lcrypto`를 링크하세요. MMC/SHM/설정 간 일괄 트랜잭션이나 자동 캐시 갱신은 별도 연결 대상입니다.

## 검증

```sh
python3 test_cache.py
```

- 테스트 전용 가짜 SDK로 암복호화 명령과 오류 반환을 검증하며 실제 KMS에 접속하지 않습니다.
- 캐시 검증, 동시 갱신, 독립 IPC 키의 SHM 복구, 사용 중 거부, 실패 시 기존 SHM 유지, BLOCK API의 SHM 재사용을 검사합니다.
- 기존 KMC1 실행 파일 경로를 `KMS_LEGACY_EXECUTABLE`로 지정하면 기존 캐시 호환성 테스트도 수행합니다.
- 실제 SDK를 링크한 실행 파일의 로컬 키/캐시 왕복도 별도 확인했습니다.
- 실제 DEV_01 암호화는 기존 kms_test와 새 kmsctl 모두 실패하여 실제 KMS 왕복 성공은 확인하지 못했습니다.
- 현재 SDK는 OpenSSL 3, VM 기본 캐시 개발 환경은 OpenSSL 1.1을 사용하여 실제 SDK 링크 시 버전 혼용 경고가 발생합니다. SDK의 libcurl 의존성도 OpenSSL 1.1을 사용하고 있습니다.
