#include "kmsctl.h"
#include "kmslib.h"
#include <stdio.h>
#include <string.h>

int kmsctl_confirm(void)
{
    char answer[64];
    char *value;
    size_t length;
    int ch;

    for (;;) {
        if (printf("  진행하시겠습니까? (y/n): ") < 0 || fflush(stdout) != 0) {
            return 0;
        }
        if (!fgets(answer, sizeof(answer), stdin)) {
            fprintf(stderr, "  Cancelled.\n");
            return 0;
        }
        if (!strchr(answer, '\n') && !feof(stdin)) {
            while ((ch = getchar()) != '\n' && ch != EOF) {
                /* Discard an overlong response; never accept a partial Y. */
            }
            fprintf(stderr, "  Enter Y or N.\n");
            continue;
        }
        value = answer + strspn(answer, " \t\r\n");
        length = strlen(value);
        while (length > 0 && strchr(" \t\r\n", value[length - 1])) {
            value[--length] = '\0';
        }
        if (length == 1 && (value[0] == 'Y' || value[0] == 'y')) {
            return 1;
        }
        if (length == 1 && (value[0] == 'N' || value[0] == 'n')) {
            printf("  Cancelled.\n");
            return 0;
        }
        fprintf(stderr, "  Enter Y or N.\n");
    }
}

int kmsctl_cache_delete(char *section)
{
    KmsCredential cred[KMS_CACHE_MAX] = {0};
    size_t count;
    size_t i;
    int ok;

    ok = 0;
    if (!section || !*section ||
        !kms_cache_read(KMS_CACHE_KEY_PATH, KMS_CACHE_FILE_PATH, cred, KMS_CACHE_MAX, &count)) {
        fprintf(stderr, "  Cannot read cache or invalid CRED_NAME.\n");
        goto done;
    }
    for (i = 0; i < count; i++) {
        if (strcmp(cred[i].section, section) == 0) {
            break;
        }
    }
    if (i == count) {
        fprintf(stderr, "  CRED_NAME not found: %s\n", section);
        goto done;
    }
    if (printf("  Delete CRED_NAME=%s USER=%s PWD=********\n", cred[i].section, cred[i].id) < 0 ||
        !kmsctl_confirm()) {
        goto done;
    }
    ok = kms_cache_delete_if_unchanged(&cred[i]);
    if (ok) {
        ok = printf("  Deleted CRED_NAME=%s\n", section) >= 0 && fflush(stdout) == 0;
    }
done:
    kms_cache_clear(cred, KMS_CACHE_MAX);
    return ok;
}
