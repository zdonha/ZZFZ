#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "lguplus_kms_client.h"

static int use_local_kms_config(void)
{
    char path[PATH_MAX];
    char *slash;
    ssize_t len;

    len = readlink("/proc/self/exe", path, sizeof(path));
    if (len < 0) {
        fprintf(stderr, "[%s] cannot resolve executable path: %s\n", __func__, strerror(errno));
        return 0;
    }

    if ((size_t)len >= sizeof(path)) {
        fprintf(stderr, "[%s] executable path is too long\n", __func__);
        return 0;
    }

    path[len] = '\0';
    slash = strrchr(path, '/');
    if (!slash) {
        fprintf(stderr, "[%s] cannot find executable directory\n", __func__);
        return 0;
    }

    slash[1] = '\0';
    if (chdir(path) != 0) {
        fprintf(stderr, "[%s] cannot open executable directory '%s': %s\n", __func__, path, strerror(errno));
        return 0;
    }

    return 1;
}

int main(int argc, char *argv[])
{
    const char *policy = NULL;
    const char *input = NULL;
    LguplusKmsResult result;
    int operation = 0;
    int opt;
    int status = EXIT_FAILURE;

    opterr = 0;
    while ((opt = getopt(argc, argv, "p:e:d:")) != -1) {
        switch (opt) {
        case 'p':
            if (policy || !*optarg) {
                goto usage;
            }
            policy = optarg;
            break;
        case 'e':
        case 'd':
            if (operation) {
                goto usage;
            }
            operation = opt;
            input = optarg;
            break;
        default:
            goto usage;
        }
    }

    if (!operation || optind != argc) {
        goto usage;
    }
    if (!policy) {
        policy = "DEV_01";
    }
    if (!use_local_kms_config()) {
        return EXIT_FAILURE;
    }

    lguplus_kms_init();
    if (operation == 'e') {
        result = lguplus_kms_encrypt(policy, input);
    } else {
        result = lguplus_kms_decrypt(policy, input);
    }

    if (result.success && result.data) {
        if (printf("%s\n", result.data) >= 0 && fflush(stdout) == 0) {
            status = EXIT_SUCCESS;
        } else {
            fprintf(stderr, "[%s] cannot write result\n", __func__);
        }
    } else {
        fprintf(stderr, "[%s] KMS %s failed\n", __func__, operation == 'e' ? "encryption" : "decryption");
    }

    free(result.data);
    lguplus_kms_cleanup();
    return status;

usage:
    fprintf(stderr, "[%s] Usage: %s [-p <policy>] (-e <plaintext> | -d <ciphertext>)\n", __func__, argv[0]);
    return EXIT_FAILURE;
}
