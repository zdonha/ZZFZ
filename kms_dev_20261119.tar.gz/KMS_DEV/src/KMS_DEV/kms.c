#include "kms_dev.h"
#include "kms_dev.p"

#include <stdio.h>

static SHM_KMS_CREDENTIAL *shm;

static int set_kms_shm_key(void)
{
    long key;

    if (commlib_getShmKey(NULL, "KMS_SHM", &key) < 0) {
        fprintf(stderr, "[%s] cannot get KMS_SHM key\n", __func__);
        return 0;
    }

    return kmslib_set_shm_key(key);
}

int kms_print_cred(void)
{
	SHM_KMS_CREDENTIAL snapshot;
	KMS_CREDENTIAL *cred;
	int i;

	if (!kmslib_get_shm_snapshot(shm, &snapshot)) {
		fprintf(stderr, "[%s] SHM snapshot failed\n", __func__);
		return 0;
	}

	printf("SHM_KMS_CREDENTIAL INFO:\n");
	printf("  kms_link_time=%s\n", commlib_printDateTime(snapshot.kms_link_time));
	printf("  update_time=%s\n", commlib_printDateTime(snapshot.update_time));
	printf("  expire_time=%s\n", commlib_printDateTime(snapshot.expire_time));
	printf("  credential_count=%d\n", snapshot.credential_count);

	for (i = 0; i < snapshot.credential_count; i++) {
		cred = &snapshot.credential[i];
		printf("  KMS_CREDENTIAL [%d] ----------------------------\n", i);
		printf("    section=%s\n", cred->section);
		printf("    policy=%s\n", cred->policy);
		printf("    user=%s\n", cred->user);
		printf("    new_pwd_enc=%s\n", cred->new_pwd_enc);
		printf("    old_pwd_enc=%s\n", cred->old_pwd_enc);
		printf("    new_pwd=%s\n", cred->new_pwd);
		printf("    old_pwd=%s\n", cred->old_pwd);
		kmslib_clear_credential(cred);
	}
	printf("  --------------------------------------\n");
	return 1;
}


int kms_get_account(const char* section, int attempt, char* user, size_t user_size, char* passwd, size_t passwd_size)
{
	return kmslib_get_account(shm, section, attempt, user, user_size, passwd, passwd_size);
}

int kms_get_account_all(const char* section, char* user, size_t user_size, char* passwd, size_t passwd_size,
                             char* old_passwd, size_t old_passwd_size)
{
	return kmslib_get_account_all(shm, section, user, user_size, passwd, passwd_size, old_passwd, old_passwd_size);
}

int kms_reload_credentials(void)
{
    if (!shm && !set_kms_shm_key()) {
        return 0;
    }

    if (!kmslib_reload_credentials()) {
        fprintf(stderr, "[%s] reload failed; fname=%s\n", __func__, kmslib_get_credential_file());
        return 0;
    }

    fprintf(stderr, "[%s] reload completed; fname=%s\n", __func__, kmslib_get_credential_file());
    return 1;
}

int kms_close_shm(void)
{
    return kmslib_detach_credential(&shm);
}

int init_kms(void)
{
    const char *fname = kmslib_get_credential_file();

    if (!set_kms_shm_key()) {
        return -1;
    }

    if (!kmslib_load_credential(&shm)) {
        fprintf(stderr, "[%s] credential/SHM load failed. fname=[%s]\n", __func__, fname);
        return -1;
    }

	fprintf(stderr, "[%s] success; load fname=%s\n", __func__, fname);

	kms_print_cred();

    return 1;
}
