#ifndef KMS_DEV_H
#define KMS_DEV_H

#include "kmslib.h"

#define MMC_CMD_CRTE       1
#define MMC_CMD_DIS        2
#define MMC_CMD_CHG        3
#define MMC_CMD_DEL        4
#define MMC_CMD_KMS_RELOAD 5

/* Standalone return codes. The RCSG package supplies its own definitions. */
#define SHM_EXIST  1
#define SHM_CREATE 2

#endif
