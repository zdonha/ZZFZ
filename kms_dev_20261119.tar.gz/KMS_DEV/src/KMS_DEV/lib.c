#define _GNU_SOURCE

#include "kms_dev.h"
#include "kms_dev.p"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/mman.h>
#include <sys/shm.h>

// from RCSG LIB: no need to add when porting to RCSG Main development.

static char commlib_timeStamp[32];
char *commlib_printDateTime (time_t when)
{
	struct tm   *pLocalTime;

	if ((pLocalTime = (struct tm*)localtime((time_t*)&when)) == NULL) {
		strcpy (commlib_timeStamp,"");
	} else {
		strftime (commlib_timeStamp, 32, "%Y-%m-%d %T", pLocalTime);
	}

	return ((char*)commlib_timeStamp);

} //----- End of commlib_printDateTime -----//



int commlib_crteShm(char *l_sysconf, char *shmName, size_t size, void **shmPtr)
{
	long   key;

	if( commlib_getShmKey(l_sysconf, shmName, &key)<0 ) {
		fprintf (stderr, "Not Found %s's SHARED_MEMORY_KEY Key\n", shmName);
		return -1;
	}

	return commlib_attachShm(key, size, shmPtr);
}


int commlib_getShmKey(char *l_sysconf, char *shmName, long *key)
{
	char tmp[64] = "0x1111";

	(void)l_sysconf;
	(void)shmName;
	if (!key) {
		return -1;
	}

//	if( conflib_getNthTokenInFileSection (l_sysconf, "[SHARED_MEMORY_KEY]", shmName, 1, tmp)<0 )
//		return -1;

	*key = strtol(tmp, 0, 0);
	return 0;
}

int commlib_attachShm(long key, size_t size, void **shmPtr)
{
    int shmid;
    int status = SHM_CREATE;
    void *address;

    if (!shmPtr || !size) {
        fprintf(stderr, "[%s] invalid SHM arguments\n", __func__);
        return -1;
    }

    *shmPtr = NULL;
    shmid = shmget((key_t)key, size, IPC_CREAT | IPC_EXCL | 0600);
    if (shmid < 0 && errno == EEXIST) {
        shmid = shmget((key_t)key, size, 0);
        status = SHM_EXIST;
    }
    if (shmid < 0) {
        fprintf(stderr, "[%s] shmget failed: %s\n", __func__, strerror(errno));
        return -1;
    }

    address = shmat(shmid, NULL, 0);
    if (address == (void *)-1) {
        fprintf(stderr, "[%s] shmat failed: %s\n", __func__, strerror(errno));
        return -1;
    }

    if (madvise(address, size, MADV_DONTDUMP) != 0) {
        fprintf(stderr, "[%s] madvise(MADV_DONTDUMP) failed: %s\n", __func__, strerror(errno));
        shmdt(address);
        return -1;
    }

    *shmPtr = address;
    return status;
}
