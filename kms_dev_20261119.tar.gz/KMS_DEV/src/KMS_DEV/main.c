#include "kms_dev.h"
#include "kms_dev.p"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int mmc_job = 1;
int db_access = 1;
int ftp_file_exist = 1;

static void run_mmc_demo(void)
{
    static const int commands[] = {MMC_CMD_DIS, MMC_CMD_CRTE, MMC_CMD_CHG, MMC_CMD_DEL};
    size_t i;

    for (i = 0; i < sizeof(commands) / sizeof(commands[0]); i++) {
        fprintf(stderr, "[%s] MMC ========================================\n", __func__);
        if (commands[i] != MMC_CMD_DIS) {
            mmc_proc(commands[i]);
        }
        mmc_proc(MMC_CMD_DIS);
    }
}

int main(int argc, char *argv[])
{
    const char *config_dir = NULL;
    int reload = 0;
    int status = EXIT_FAILURE;
    int i;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--config-dir") == 0 && i + 1 < argc) {
            config_dir = argv[++i];
        } else if (strcmp(argv[i], "--reload-kms") == 0) {
            reload = 1;
        } else {
            fprintf(stderr, "[%s] usage: %s [--config-dir DIR] [--reload-kms]\n", __func__, argv[0]);
            return EXIT_FAILURE;
        }
    }

    if (config_dir && chdir(config_dir) != 0) {
        fprintf(stderr, "[%s] cannot open config directory '%s': %s\n", __func__, config_dir, strerror(errno));
        return EXIT_FAILURE;
    }

    if (reload) {
        return mmc_proc(MMC_CMD_KMS_RELOAD) == 1 ? EXIT_SUCCESS : EXIT_FAILURE;
    }

    if (init() < 0) {
        fprintf(stderr, "[%s] initialization failed\n", __func__);
        goto done;
    }

    if (mmc_job) {
		fprintf(stderr, "[%s] MMC ########################################\n", __func__);
        run_mmc_demo();
    }

    if (ftp_file_exist) {
		fprintf(stderr, "[%s] FTP ########################################\n", __func__);
        ftp_proc();
    }

    if (db_access) {
		fprintf(stderr, "[%s] DB ########################################\n", __func__);
        db_proc();
    }

    status = EXIT_SUCCESS;

done:
    if (!kms_close_shm()) {
        status = EXIT_FAILURE;
    }
    kmslib_cleanup();
    return status;
}
