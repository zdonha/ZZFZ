#ifndef KMS_DEV_P
#define KMS_DEV_P

int init(void);
int db_proc(void);
int ftp_proc(void);
int mmc_proc(int cmd);

int init_kms(void);
int kms_close_shm(void);
int kms_reload_credentials(void);
int kms_print_cred(void);
int kms_get_account(const char *section, int attempt, char *user, size_t user_size, char *passwd, size_t passwd_size);
int kms_get_account_all(const char *section, char *user, size_t user_size, char *passwd, size_t passwd_size,
                             char *old_passwd, size_t old_passwd_size);
char *commlib_printDateTime (time_t when);

int commlib_crteShm(char *l_sysconf, char *shmName, size_t size, void **shmPtr);
int commlib_getShmKey(char *l_sysconf, char *shmName, long *key);
int commlib_attachShm(long key, size_t size, void **shmPtr);

#endif
