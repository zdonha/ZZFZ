#include "kms_dev.h"
#include "kms_dev.p"

#include <stdio.h>

#define db_connect_success	1
#define db_login_fail		2

static int db_connect(const char *db_id, const char *db_pwd)
{
	fprintf(stderr, "[%s] db_id=%s db_pwd=%s\n", __func__, db_id, db_pwd);	// check

	return db_connect_success;
}

int db_proc(void)
{
	int ret;
	char db_id[KMSLIB_USER_SIZE];
	char db_pwd[KMSLIB_PWD_SIZE];
	char old_pwd[KMSLIB_PWD_SIZE];

	if (!kms_get_account_all("DB", db_id, sizeof(db_id), db_pwd, sizeof(db_pwd), old_pwd, sizeof(old_pwd))) {
		fprintf(stderr, "[%s] failed to get DB account\n", __func__);
		ret = 0;
		goto done;
	}

	ret = db_connect(db_id, db_pwd);
	if (ret == db_login_fail && old_pwd[0]) {
		fprintf(stderr, "[%s] DB login failed; retrying once with the previous password\n", __func__);
		ret = db_connect(db_id, old_pwd);
	}

	if (ret != db_connect_success) {
		fprintf(stderr, "[%s] DB connect failed; result=%d\n", __func__, ret);
	}

done:
	kmslib_clear_buffer(db_id, sizeof(db_id));
	kmslib_clear_buffer(db_pwd, sizeof(db_pwd));
	kmslib_clear_buffer(old_pwd, sizeof(old_pwd));
	return ret;
}

