#include "kms_dev.h"
#include "kms_dev.p"

#include <stdio.h>

#define ftp_send_success	1
#define ftp_login_fail		2
#define ftp_connect_fail	3

static int send_ftp(char *id, char *pwd)
{
	fprintf(stderr, "[%s] id=%s pwd=%s\n", __func__, id, pwd);	// check

	return ftp_send_success;
//	return ftp_login_fail;
//	return ftp_connect_fail;
}

int ftp_proc(void)
{
	int ret;
	char id[KMSLIB_USER_SIZE];
	char pwd[KMSLIB_PWD_SIZE];
	char old_pwd[KMSLIB_PWD_SIZE];

	if (!kms_get_account_all("FTP", id, sizeof(id), pwd, sizeof(pwd), old_pwd, sizeof(old_pwd))) {
		fprintf(stderr, "[%s] failed to get FTP account\n", __func__);
		ret = -1;
		goto done;
	}

	ret = send_ftp(id, pwd);
	if (ret == ftp_login_fail && old_pwd[0]) {
		fprintf(stderr, "[%s] FTP login failed; retrying once with the previous password\n", __func__);
		ret = send_ftp(id, old_pwd);
	}

	if (ret != ftp_send_success) {
		fprintf(stderr, "[%s] ftp send fail; result=%d\n", __func__, ret);
	}

done:
	kmslib_clear_buffer(id, sizeof(id));
	kmslib_clear_buffer(pwd, sizeof(pwd));
	kmslib_clear_buffer(old_pwd, sizeof(old_pwd));
	return ret;
}
