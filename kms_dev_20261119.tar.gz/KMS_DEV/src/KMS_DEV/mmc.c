#include "kms_dev.h"
#include "kms_dev.p"

#include <stdio.h>

static int crte_kms_cred(char* section, char* user, char* passwd, const char* policy)
{
	fprintf(stderr, "[%s] section=%s user=%s passwd=%s policy=%s\n", __func__, section, user, passwd, policy);

	return kmslib_add_credential(section, user, passwd, policy);
}

static int dis_kms_cred(void)
{
	kms_print_cred();

	return 1;
}

static int chg_kms_cred(char* section, char* user, char* passwd, const char* policy)
{
	return kmslib_change_credential(section, user, passwd, policy);
}

static int del_kms_cred(char* section)
{
	return kmslib_delete_credential(section);
}


int mmc_proc(int cmd)
{
	fprintf(stderr, "[%s] ......cmd=%d\n", __func__, cmd);

	if (cmd == MMC_CMD_CRTE) {			// kms_cred 등록
		return crte_kms_cred("TEST", "donha", "123123", "01");
	} else if (cmd == MMC_CMD_DIS) {	// kms_cred 조회
		dis_kms_cred();
	} else if (cmd == MMC_CMD_CHG) {	// kms_cred 변경
		return chg_kms_cred("TEST", "donha", "asdfasdf", "01");
	} else if (cmd == MMC_CMD_DEL) {	// kms_cred 삭제
		return del_kms_cred("TEST");
	} else if (cmd == MMC_CMD_KMS_RELOAD) {
		return kms_reload_credentials();
	} else {
		fprintf(stderr, "[%s] unsupported MMC command: %d\n", __func__, cmd);
	}

	return 1;
}

