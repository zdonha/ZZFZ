#include "kms_dev.h"
#include "kms_dev.p"

#include <stdio.h>

int init(void)
{
	if (init_kms() < 0) {
		fprintf(stderr, "[%s] init kms failed.\n", __func__);
		return -1;
	}

	return 1;
}
