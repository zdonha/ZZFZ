#!/bin/bash
# CCS subscriber bulk loader (Altibase iLoader).
# Usage: ./ccs.sh FIRST_MDN LAST_MDN [TYPE] [--replace-range]
# Default: APPEND without deleting any existing record.
set -euo pipefail

usage()
{
    echo "USAGE: $0 FIRST_MDN LAST_MDN [TYPE] [--replace-range]" >&2
    echo "  TYPE: 0=SMS, 3=FREE, 4=AL2A, 5=MEDIA (default 0)" >&2
    echo "  EX  : $0 01010000000 01010000999 0" >&2
    echo "  EX  : $0 01010000000 01010000999 0 --replace-range" >&2
    exit 1
}

[[ $# -ge 2 && $# -le 4 ]] || usage
FIRST_MDN=$1
LAST_MDN=$2
TYPE=0
REPLACE=0

if [[ ${3:-} == --replace-range ]]; then
    REPLACE=1
elif [[ $# -ge 3 ]]; then
    TYPE=$3
fi
if [[ ${4:-} == --replace-range ]]; then
    REPLACE=1
elif [[ $# -ge 4 ]]; then
    usage
fi

[[ "$FIRST_MDN" =~ ^0[0-9]{10}$ ]] || usage
[[ "$LAST_MDN" =~ ^0[0-9]{10}$ ]] || usage
[[ "$TYPE" =~ ^(0|3|4|5)$ ]] || usage
START=$((10#$FIRST_MDN))
END=$((10#$LAST_MDN))
(( START <= END )) || { echo 'ERROR: invalid MDN range' >&2; exit 1; }
EXPECTED=$((END - START + 1))

command -v iloader >/dev/null || { echo 'ERROR: iloader not found in PATH' >&2; exit 1; }
if (( REPLACE )); then
    command -v isql >/dev/null || { echo 'ERROR: isql not found in PATH' >&2; exit 1; }
fi

DB_HOST=${CCS_DB_HOST:-127.0.0.1}
DB_USER=${CCS_DB_USER:-ccs}
DB_PORT=${CCS_DB_PORT:-}
DB_PASS=${CCS_DB_PASS:-}

if [[ -z "$DB_PASS" ]]; then
    read -r -s -p "${DB_USER}@${DB_HOST} DB password: " DB_PASS
    echo
fi
[[ -n "$DB_PASS" ]] || { echo 'ERROR: empty DB password' >&2; exit 1; }

BASE_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
FMT="$BASE_DIR/ccs_subs.fmt"
DAT="$BASE_DIR/ccs_subs.dat"
LOG="$BASE_DIR/ccs_subs.log"
BAD="$BASE_DIR/ccs_subs.bad"
DEL_LOG="$BASE_DIR/ccs_delete.log"
TMP_DAT="$DAT.tmp.$$"
trap 'rm -f "$TMP_DAT"' EXIT

CONN=(-s "$DB_HOST" -u "$DB_USER" -p "$DB_PASS")
if [[ -n "$DB_PORT" ]]; then
    CONN+=(-port "$DB_PORT")
fi

echo "[INFO] MDN: $FIRST_MDN ~ $LAST_MDN, TYPE=$TYPE, rows=$EXPECTED"

# Generate table metadata from the live database once.
if [[ ! -s "$FMT" ]]; then
    echo '[INFO] Generate iLoader FORM...'
    iloader formout "${CONN[@]}" -T CCS_SUBS_TBL -f "$FMT"
    [[ -s "$FMT" ]] || { echo 'ERROR: formout failed' >&2; exit 1; }
fi

FORM_COLS=$(awk '
    /^[[:space:]]*\{[[:space:]]*$/ { in_table=1; next }
    in_table && /^[[:space:]]*\}[[:space:]]*$/ { in_table=0 }
    in_table && /;/ { cols++ }
    END { print cols+0 }
' "$FMT")
if (( FORM_COLS != 11 )); then
    echo "ERROR: FORM must have 11 columns, found $FORM_COLS. Check $FMT" >&2
    exit 1
fi

echo '[INFO] Generate DAT...'
bash "$BASE_DIR/make_subs.sh" 0 "$FIRST_MDN" "$LAST_MDN" "$TYPE" > "$TMP_DAT"
ACTUAL=$(wc -l < "$TMP_DAT")
[[ "$ACTUAL" -eq "$EXPECTED" ]] || { echo "ERROR: DAT rows $ACTUAL != $EXPECTED" >&2; exit 1; }
awk -F, 'NR <= 3 { if (NF != 11) exit 1 } NR == 3 { exit }' "$TMP_DAT" || {
    echo 'ERROR: expected 11 CCS columns in DAT' >&2
    exit 1
}
mv -f "$TMP_DAT" "$DAT"
echo "[INFO] DAT ready: $DAT ($ACTUAL rows)"

if (( REPLACE )); then
    echo "[WARN] DELETE existing CCS_SUBS_TBL rows within $FIRST_MDN ~ $LAST_MDN"
    read -r -p "Type DELETE to continue: " ANSWER
    [[ "$ANSWER" == DELETE ]] || { echo '[INFO] Cancelled'; exit 1; }
    if ! printf "DELETE FROM CCS_SUBS_TBL WHERE MDN BETWEEN '%s' AND '%s';\n" "$FIRST_MDN" "$LAST_MDN" \
          | isql "${CONN[@]}" > "$DEL_LOG" 2>&1; then
        echo "ERROR: SQL execution failed. See $DEL_LOG" >&2
        exit 1
    fi
    if grep -Eqi 'ERR-[0-9]+|\bERROR\b' "$DEL_LOG"; then
        echo "ERROR: DELETE reported an SQL error. See $DEL_LOG" >&2
        exit 1
    fi
    echo "[INFO] Range DELETE submitted. See $DEL_LOG"
fi

rm -f "$BAD" "$LOG"
echo '[INFO] Start iLoader (array=1000, commit=10, atomic)...'
if ! iloader in "${CONN[@]}" \
    -f "$FMT" -d "$DAT" -mode append \
    -array 1000 -commit 10 -atomic \
    -log "$LOG" -bad "$BAD"; then
    echo "ERROR: iLoader failed. See $LOG and $BAD" >&2
    exit 1
fi

if [[ -s "$BAD" ]]; then
    echo "ERROR: failed records found in $BAD" >&2
    exit 1
fi

if [[ -f "$LOG" ]] && grep -Eq 'Error Row Count[[:space:]]*:[[:space:]]*[1-9]' "$LOG"; then
    echo "ERROR: load log reports failed records: $LOG" >&2
    exit 1
fi

LOADED=''
if [[ -f "$LOG" ]]; then
    LOADED=$(awk -F: '/Load Row Count[[:space:]]*:/ {
        gsub(/[^0-9]/, "", $2)
        print $2
        exit
    }' "$LOG")
fi
if [[ -n "$LOADED" && "$LOADED" -ne "$EXPECTED" ]]; then
    echo "ERROR: Load Row Count $LOADED != expected $EXPECTED; check $LOG" >&2
    exit 1
fi

echo "[OK] iLoader completed ($EXPECTED expected records). Check $LOG"
