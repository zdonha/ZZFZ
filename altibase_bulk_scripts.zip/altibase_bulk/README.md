# Altibase CCS bulk loader (RHEL 8.10)

## Files
- `make_subs.sh`: Generate iLoader CSV-style data file (SUC=0 CCS / SUC=1 WOW).
- `ccs.sh`: Generate CCS data, optionally DELETE target range, then load using iLoader.

## Setup
```bash
chmod +x make_subs.sh ccs.sh
export PATH="$ALTIBASE_HOME/bin:$PATH"
```

## Dry run: generate only (does not connect to DB)
```bash
./make_subs.sh 0 01010000000 01010000009 0 > test.dat
head -3 test.dat
wc -l test.dat
```

## First-time format verification
The loader generates `ccs_subs.fmt` via Altibase `iloader formout` if missing. Confirm it lists the expected 11 CCS columns in the same order as the original `INSERT INTO CCS_SUBS_TBL VALUES(...)`.

## Load (no deletion)
```bash
./ccs.sh 01010000000 01010000999 0
```

## Replace only the specified MDN range
```bash
./ccs.sh 01010000000 01010000999 0 --replace-range
```
Explicitly type `DELETE` when prompted. WARNING: range deletion can be expensive and is committed separately from the following load. It is not an atomic replacement operation.

## Optional connection settings
- `CCS_DB_HOST`: default 127.0.0.1
- `CCS_DB_USER`: default ccs
- `CCS_DB_PORT`: optional server port
- `CCS_DB_PASS`: optional; if unset, script prompts for a password

## Output and safety notes
- `ccs_subs.dat`, `ccs_subs.fmt`, `ccs_subs.log`, `ccs_subs.bad`
- `ccs_delete.log` is produced only when replacing a range.
- `-array 1000 -commit 10 -atomic`: commits every 10 arrays of 1000, approximately 10000 rows.
- Verify the empty-string column (`""`) is loaded equivalently to the original SQL `''` on the target schema.
- Verify MDN (11 chars) and IMSI (15 chars) for first and last loaded rows.
- For large ranges, first test 10 / 1000 rows and check `ccs_subs.bad` and row counts.
- `iloader -mode replace` is intentionally NOT used; that would delete the whole table.
- Password on process command line may be visible to system administrators via process listing. Consider supported password-file options in deployment and do not commit credentials.
