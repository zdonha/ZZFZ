#!/bin/bash
# CCS(0) / WOW(1) subscriber records for Altibase iLoader.
# Usage: ./make_subs.sh 0|1 FIRST_MDN LAST_MDN [TYPE] > target.dat
set -euo pipefail

usage()
{
    echo "USAGE: $0 SUC FIRST_MDN LAST_MDN [TYPE]" >&2
    echo "  SUC  : 0=CCS, 1=WOW" >&2
    echo "  TYPE : 0=SMS, 3=FREE, 4=AL2A, 5=MEDIA (CCS only; default 0)" >&2
    echo "  EX   : $0 0 01010000000 01010000999 0 > ccs_subs.dat" >&2
    exit 1
}

[[ $# -ge 3 && $# -le 4 ]] || usage
SUC=$1
FIRST_MDN=$2
LAST_MDN=$3
TYPE=${4:-0}

[[ "$SUC" =~ ^[01]$ ]] || usage
[[ "$FIRST_MDN" =~ ^0[0-9]{10}$ ]] || { echo "ERROR: FIRST_MDN must be 11 digits starting with 0" >&2; exit 1; }
[[ "$LAST_MDN" =~ ^0[0-9]{10}$ ]] || { echo "ERROR: LAST_MDN must be 11 digits starting with 0" >&2; exit 1; }
[[ "$TYPE" =~ ^(0|3|4|5)$ ]] || { echo "ERROR: unsupported TYPE=$TYPE" >&2; exit 1; }

FIRST=$((10#$FIRST_MDN))
LAST=$((10#$LAST_MDN))
(( FIRST <= LAST )) || { echo "ERROR: FIRST_MDN > LAST_MDN" >&2; exit 1; }

# The first column (MDN) is kept as 11 digits including its leading 0.
# IMSI follows the original script rule: 45000 + 10-digit numeric MDN.
# awk uses exact integers for this 11-digit MDN range (< 2^53).
awk -v first="$FIRST" -v last="$LAST" -v suc="$SUC" -v type="$TYPE" '
BEGIN {
    for (i = first; i <= last; i++) {
        mdn  = sprintf("%011.0f", i)
        imsi = sprintf("45000%010.0f", i)
        if (suc == 0) {
            printf "\"%s\",\"%s\",0,%d,0,0,\"\",0,0,0,0\n", mdn, imsi, type
        } else {
            printf "\"%s\",\"%s\",0,0,0,\"\",0\n", mdn, imsi
        }
    }
}
'
